import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { NavigationEnd, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { LoginComponent } from './components/login/login.component';
import { ModalComponent } from './modal/modal.component';
import { SelectService } from './services/select.service';
import { User } from './types/user';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  title = 'Suri'
  image = environment.imagePath;
  isHeaderShown = true;
  mouseover: boolean = false;
  event$: any;
  icon: string = '';
  user: User | undefined;
  isLoggedIn = false;
  constructor(private router: Router, private dialog: MatDialog, private selectService: SelectService) {

  }


  ngOnInit(): void {
    this.isHeaderShown = true;
    this.router.events.subscribe((val) => {
      if (val instanceof NavigationEnd) {
       let urlPart = val.url;
       this.isHeaderShown = urlPart.includes('home');
        if (!this.user?.firstName?.length) {
          this.user = this.selectService.getUser();
        }
        this.icon = this.generateIcon(this.user?.firstName, this.user?.lastName);
      }
      //this.isHeaderShown = (val. == '/login');
    });

    this.user = this.selectService.getUser();
    this.icon = this.generateIcon(this.user?.firstName, this.user?.lastName);

  }
  goToLogin() {
    // this.isHeaderShown = false;
    this.dialog.open(LoginComponent, {
      data: {
        message: "Error!!!"
      }
    });
    // this.router.navigate(['/login']);
  }

  goToMenu(){
    let userFromStorage:any = localStorage.getItem('currentUser');
    if (userFromStorage)
        userFromStorage = JSON.parse(userFromStorage);
    if (userFromStorage && (!Array.isArray(userFromStorage) || userFromStorage.length) ){
      userFromStorage?.rule === "מנהל" ?
      this.router.navigate(['managerMenu']) :
      userFromStorage.rule === "מורה" ?
        this.router.navigate(['teacherMenu']) :
        this.router.navigate(['secretaryMenu']);
    }
    
    else this.router.navigate(['/home']);
  }

  goToAbout() {
    this.router.navigate(['/about']);
  }


  // @HostListener('mouseover')
  // onMouseOver() {
  //   this.mouseover = true;
  // }

  // @HostListener('mouseout')
  // onMouseOut() {
  //   this.mouseover = false;
  // }

  getUserDetails() {
    if (!this.selectService.user) {
      this.icon = "";
      return;
    }

    this.icon = this.generateIcon(this.selectService.user?.firstName, this.selectService.user?.lastName);
    //return this.selectService.user?.firstName + ' ' + this.selectService.user?.lastName;
  }

  generateIcon(firstName: string, lastName: string) {
    console.log(firstName.toString()[0] + lastName.toString()[0])
    if (!firstName.length) {
      this.isLoggedIn = false;
      return '';
    }
    this.isLoggedIn = true;

    return firstName.toString()[0] + lastName.toString()[0];
  }


}
