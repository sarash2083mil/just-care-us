import { APP_INITIALIZER, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ManagerMenuModule } from './components/manager-menu/manager-menu.module';
import { SecretaryMenuModule } from './components/secretary-menu/secretary-menu.module';
import { LoginModule } from './components/login/login.module';
import { ConfigurationService } from './services/configuration.service';
import { environment } from 'src/environments/environment';
import { AttendanceMarkingModule } from './components/attendance-marking/attendance-marking.module';
import { ClassesModule } from './components/classes/classes.module';
import { ViewClassModule } from './components/view-class/view-class.module';
import { GraphsModule } from './components/graphs/graphs.module';
import { CertificateOfAbsenceModule } from './components/certificate-of-absence/certificate-of-absence.module';
import { AbsencesClassModule } from './components/absences-class/absences-class.module';
import { AbsencesStudentModule } from './components/absences-student/absences-student.module';
import { PrintAbsencesComponent } from './components/print-absences/print-absences.component';
import { PrintAbsencesModule } from './components/print-absences/print-absences.module';
import { NewUserModule } from './components/new-user/new-user.module';
import { ViewAllUsersModule } from './components/view-all-users/view-all-users.module';
import { PrivateAreaModule } from './components/private-area/private-area.module';
import { TeacherMenuModule } from './components/teacher-menu/teacher-menu.module';
import { PasswordResetComponent } from './components/password-reset/password-reset.component';
import { PasswordResetModule } from './components/password-reset/password-reset.module';
import { AngularDesignModule } from './design.module';
import { ModalComponent } from './modal/modal.component';
import { AboutComponent } from './components/about/about.component';



@NgModule({
  declarations: [
    AppComponent,
    ModalComponent,
    AboutComponent,
  ],
  imports: [
    BrowserModule,
    CommonModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    RouterModule,
    ManagerMenuModule,
    SecretaryMenuModule,
    LoginModule,
    AttendanceMarkingModule,
    ClassesModule,
    ViewClassModule,
    GraphsModule,
    CertificateOfAbsenceModule,
    AbsencesClassModule,
    AbsencesStudentModule,
    PrintAbsencesModule,
    NewUserModule,
    ViewAllUsersModule,
    PrivateAreaModule,
    TeacherMenuModule,
    PasswordResetModule,
    AngularDesignModule,
  ],
  providers: [{ provide: APP_INITIALIZER, useFactory: initConfigValues, deps: [ConfigurationService], multi: true }],
  bootstrap: [AppComponent]
})
export class AppModule { }


export function initConfigValues(config: ConfigurationService) {
  return ((_: any) => config.initConfiguration(environment.configPath));
}


