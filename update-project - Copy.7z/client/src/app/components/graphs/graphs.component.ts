import { Component, OnInit } from '@angular/core';
import { tap } from 'rxjs/operators';
import { SelectService } from 'src/app/services/select.service';
import { student } from 'src/app/types/student';

@Component({
  selector: 'app-graphs',
  templateUrl: './graphs.component.html',
  styleUrls: ['./graphs.component.scss']
})
export class GraphsComponent implements OnInit {

  multiAxisData: any;
  multiAxisOptions: any
  allClasses: any = []
  classesWithAbsences: any = []
  monthsNames = ['ינואר', 'פברואר', 'מרץ', 'אפריל'
    , 'מאי', 'יוני', 'יולי', 'אוגוסט',
    'ספטמבר', 'אוקטובר', 'נובמבר', 'דצמבר'];
  monthNow: string = ''


  constructor(private selectHttp: SelectService) { }

  ngOnInit(): void {
    this.monthNow = this.monthsNames[new Date().getMonth()]

    //שליפת כל החיסורים החודש  לפי כיתות
    this.selectHttp.getAbsencesInClassesTheMonth$().pipe(
      tap(s => console.log('classesWithAbsences', s)),
      tap(s => this.classesWithAbsences = s),
    ).subscribe()

    //שליפת מספר התלמידים בכל כיתה
    this.selectHttp.getNumStudentsInClasses$().pipe(
      tap(s => console.log('allClasses', s)),
      tap(s => this.allClasses = s),
      tap(s => this.buildData()),
      tap(s => this.buildGraphs())
    ).subscribe()
  }

  //הפונקציה עוברת על מערך הכיתות ועוברת על מערך החיסורים
  //וכיתה שאין לה שום חיסורים היא מוסיפה לה 0 למספר החיסורים
  //כדי שגם היא תוצג בגרף
  buildData() {
    for (let i = 0; i < this.allClasses.length; i++) {
      let flag = true
      for (let j = 0; j < this.classesWithAbsences.length; j++) {
        if (this.classesWithAbsences[j]._id == this.allClasses[i]._id) {
          flag = false
          this.allClasses[i].numAbsences = this.classesWithAbsences[j].numAbsences
        }
      }
      if (flag)
        this.allClasses[i].numAbsences = 0
    }
    //הדפסת מערך הכיתות עם כל החיסורים גם של הכיתות שמספר החיסורים שלהן הוא 0
    console.log('allClassesAfterUpdate', this.allClasses);
    //הדפסת כמות החיסורים בכיתה מתחילת החודש
    console.log(this.allClasses.map((c: { numAbsences: any; }) => c.numAbsences));
    //הדפסת אחוז החיסורים ביחס לכמות התלמידים בכיתה
    console.log(this.allClasses.map((c: { numStudents: any, numAbsences: any; }) => c.numAbsences * 100 / c.numStudents))
  }

  buildGraphs() {
    this.multiAxisData = {
      // labels: ['א1', 'א2', 'ב1', 'ב2', 'ב3', 'ג1', 'ג2', 'ד1', 'ד2'],
      labels: this.allClasses.map((c: { _id: any; }) => c._id),
      datasets: [{
        label: 'כמות החיסורים בכיתה מתחילת החודש ',
        backgroundColor: 'pink',
        //  [
        //     'pink',
        //     'gray',
        //     'pink',
        //     'gray',
        //     'pink',
        //     'gray',
        //     'pink'
        // ],
        yAxisID: 'y',
        data: this.allClasses.map((c: { numAbsences: any; }) => c.numAbsences)
        //  data: [9,8,7,6,5]
      }, {
        label: 'אחוז החיסורים ביחס לכמות התלמידים בכיתה',
        backgroundColor: 'brown',
        yAxisID: 'y1',
        data: this.allClasses.map((c: { numStudents: any, numAbsences: any; }) => c.numAbsences * 100 / c.numStudents)
        //  data: [5,6,7,8,9,10,11]
      }]
    };

    this.multiAxisOptions = {
      plugins: {
        legend: {
          labels: {
            //צבע 2 כותרות התרשימים
            color: '#495057'
          }
        },
        tooltips: {
          mode: 'index',
          intersect: true
        }
      },
      scales: {
        x: {
          ticks: {
            //צבע שמות הכיתות
            color: '#495057'
          },
          grid: {
            //צבע השורות העומדות
            color: '#ebedef'
          }
        },
        y: {
          type: 'linear',
          display: true,
          position: 'left',
          ticks: {
            min: 0,
            max: 100,
            //צבע המספרים בצד שמאל
            color: '#495057'
          },
          grid: {
            //צבע השורות השוכבות
            color: '#ebedef'
          }
        },
        y1: {
          type: 'linear',
          display: true,
          position: 'right',
          grid: {
            drawOnChartArea: false,
            //צבע הקווים הקטנים שבין המספרים
            color: '#ebedef'
          },
          ticks: {
            min: 0,
            max: 100,
            //צבע המספרים בצד ימין
            color: '#495057'
          }
        }
      }
    };
  }
}












