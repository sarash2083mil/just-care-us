import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrintAbsencesComponent } from './print-absences.component';
import { AbsencesStudentModule } from '../absences-student/absences-student.module';



@NgModule({
  declarations: [PrintAbsencesComponent],
  imports: [
    CommonModule,
    AbsencesStudentModule
  ],
  exports: [PrintAbsencesComponent]
})
export class PrintAbsencesModule { }
