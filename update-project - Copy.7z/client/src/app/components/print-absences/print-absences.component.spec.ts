import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrintAbsencesComponent } from './print-absences.component';

describe('PrintAbsencesComponent', () => {
  let component: PrintAbsencesComponent;
  let fixture: ComponentFixture<PrintAbsencesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrintAbsencesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrintAbsencesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
