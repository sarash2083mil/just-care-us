import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NEVER, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { SelectService } from 'src/app/services/select.service';
import { Location } from '@angular/common';


@Component({
  selector: 'app-print-absences',
  templateUrl: './print-absences.component.html',
  styleUrls: ['./print-absences.component.scss']
})
export class PrintAbsencesComponent implements OnInit {

  theAbsences$: Observable<any[]> = NEVER
  startDate: Date | undefined
  endDate: Date | undefined
  whatToPrint:string=''

  constructor(private route: ActivatedRoute, private router: Router, private selectHttp: SelectService,
    private _location: Location) {
    this.route.params.subscribe((params: Params) => {
      this.startDate = params.d1;
      this.endDate = params.d2;
      this.whatToPrint=params?.whatToPrint
      console.log('startDate', this.startDate);
      console.log('endDate', this.endDate);
      console.log('whatToPrint', this.whatToPrint);
    });
  }

  ngOnInit(): void {
   this.whatToPrint=='allSchool'?
    this.theAbsences$ = this.selectHttp.getAbsencesOfAllStudentsInSchool$(this.startDate, this.endDate).pipe(
      tap(absences => console.log('absences', absences)
      )
    ):
    this.theAbsences$ = this.selectHttp.getAbsencesOfStudentsByClass$(this.whatToPrint,this.startDate, this.endDate).pipe(
      tap(absences => console.log('absences', absences),
      )
    )
    this.whatToPrint=''
  }

  goToClass() {
    this._location.back();
  }

}
