import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NEVER, Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { DeleteService } from 'src/app/services/delete.service';
import { InsertService } from 'src/app/services/insert.service';
import { SelectService } from 'src/app/services/select.service';
import { UpdateService } from 'src/app/services/update.service';
import { student } from 'src/app/types/student';

@Component({
  selector: 'app-view-class',
  templateUrl: './view-class.component.html',
  styleUrls: ['./view-class.component.scss']
})
export class ViewClassComponent implements OnInit {

  studentFormGroup: FormGroup | undefined
  setStudent: student | undefined
  showUpdateStudentDialog: boolean = false
  showDeleteStudentDialog: boolean = false
  showAddStudentDialog: boolean = false
  nameClass: string = '';
  studentInClass$: Observable<student[]> = NEVER

  constructor(private route: ActivatedRoute, private router: Router, private formBuilder: FormBuilder
    , private deleteHttp: DeleteService, private selectHttp: SelectService
    , private insertHttp: InsertService, private updateHttp: UpdateService) {
    this.route.params.subscribe((params: Params) => {
      this.nameClass = params.nameClass;
      console.log(this.nameClass);

    });
  }

  ngOnInit() {
    this.selectAllStudentsInClass()
    this.restart()
  }

  selectAllStudentsInClass() {
    this.studentInClass$ = this.selectHttp.getStudentsByClass$(this.nameClass).pipe(
      tap(s => console.log(s)),
      tap(s => s?.length == 0 ?
        this.router.navigate([this.router.url.search('managerMenu') == 1 ?
          'managerMenu/classes' :
          'secretaryMenu/classes']) :
        console.log('s.length', s.length)))
  }

  restart() {
    this.studentFormGroup = this.formBuilder.group({
      firstName: new FormControl(''),
      lastName: new FormControl(''),
      idNumber: new FormControl(''),
      gender: new FormControl(''),
      phone1: new FormControl(''),
      phone2: new FormControl(''),
      address: new FormControl(''),
      remarks: new FormControl(''),
      class: new FormControl(''),
    })
  }

  updateStudent(s: student) {
    this.setStudent = s
    this.studentFormGroup = this.formBuilder.group({
      firstName: this.setStudent.firstName,
      lastName: this.setStudent.lastName,
      idNumber: this.setStudent.idNumber,
      gender: this.setStudent.gender,
      phone1: this.setStudent.phone1,
      phone2: this.setStudent.phone2,
      address: this.setStudent.address,
      remarks: this.setStudent.remarks,
      class: this.nameClass,
    })
    this.showUpdateStudentDialog = true
  }

  deleteStudent(s: student) {
    this.setStudent = s
    this.showDeleteStudentDialog = true
  }

  HideDeleteStudentDialog() {
    this.showDeleteStudentDialog = false;
    this.setStudent = undefined
  }

  saveDeleteStudentDialog() {
    console.log(this.setStudent);
    this.showDeleteStudentDialog = false;
    this.deleteHttp.deleteOneStudent$(this.setStudent?._id ? this.setStudent?._id : undefined).pipe(
      tap(ans => console.log('answer:', ans)),
      tap(ans => this.selectAllStudentsInClass())
    ).subscribe()
  }

  HideUpdateStudentDialog() {
    this.showUpdateStudentDialog = false
    this.setStudent = undefined
    this.restart()
  }

  saveUpdateStudentDialog() {
    console.log('student in update', this.studentFormGroup?.value);
    this.showUpdateStudentDialog = false
    this.updateHttp.updateStudent$(this.setStudent?._id ? this.setStudent?._id : '', this.studentFormGroup?.value).pipe(
      tap(ans => console.log('answer:', ans)),
      tap(ans => this.selectAllStudentsInClass()),
    ).subscribe()
    this.setStudent = undefined
    this.restart()
  }

  addNewStudent() {
    this.showAddStudentDialog = true
  }

  HideAddStudentDialog() {
    this.showAddStudentDialog = false
    this.setStudent = undefined
  }

  saveAddStudentDialog() {
    this.studentFormGroup?.controls.class.setValue(this.nameClass);
    console.log('new student', this.studentFormGroup?.value);
    this.showAddStudentDialog = false
    this.insertHttp.addnewStudent$(this.studentFormGroup?.value).pipe(
      tap(ans => console.log(ans)),
      tap(ans => this.selectAllStudentsInClass())
    ).subscribe()
    this.setStudent = undefined
    this.restart()
  }
}