import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup,Validators } from '@angular/forms';
import { NEVER, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { DeleteService } from 'src/app/services/delete.service';
import { InsertService } from 'src/app/services/insert.service';
import { SelectService } from 'src/app/services/select.service';
import { UpdateService } from 'src/app/services/update.service';
import { User } from 'src/app/types/user';

@Component({
  selector: 'app-view-all-users',
  templateUrl: './view-all-users.component.html',
  styleUrls: ['./view-all-users.component.scss']
})
export class ViewAllUsersComponent implements OnInit {

  userFromUserFormGroup: any
  userFormGroup: FormGroup | undefined
  showAddUserDialog: boolean = false
  listAllUsers$: Observable<User[]> = NEVER
  setUser: User | undefined
  showDeleteUserDialog: boolean = false
  showUpdateUserDialog: boolean = false
  invalidForm = false;
  userFromService:User={
    firstName: '',
    lastName: '',
    _id: '',
    idNumber: '',
    phone: '',
    mailAddress: '',
    password: '',
    rule: ''
  }

  // selectedRule = '';

  constructor(private selectHttp: SelectService, private insertHttp: InsertService,
    private deleteHttp: DeleteService, private updateHttp: UpdateService, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.userFromService=this.selectHttp.getUser()
    console.log('tryyyyyyyyyyyyyyyyyyyyy',this.userFromService);
    
    this.getAllUsers()
    this.restart()
  }

  getAllUsers() {
    console.log('in getAllUsers');
    this.listAllUsers$ = this.selectHttp.getAllUsers$().pipe(
      tap(users => console.log('users', users)
      )
    )
  }

  restart() {
    this.userFormGroup = this.formBuilder.group({
      firstName: new FormControl('',Validators.required),
      lastName: new FormControl('',Validators.required),
      idNumber: new FormControl('',Validators.required),
      phone: new FormControl('',Validators.required),
      mailAddress: new FormControl('',[Validators.required,Validators.email]),
      password: new FormControl(Math.ceil((Math.random() * 100000000)).toString(),Validators.required),
      rule: new FormControl('מורה'),
    })
  }

  //----------------------------------------------------------------------- הוספת משתמש חדש

  addNewUser() {
    this.restart();
    this.showAddUserDialog = true
  }

  HideAddUserDialog() {
    this.showAddUserDialog = false
    this.restart()
  }

  saveAddUserDialog() {
    if(this.userFormGroup?.status == "INVALID") {
      this.invalidForm = true;
      this.userFormGroup.markAllAsTouched();
   //   this.userFormGroup.setErrors();
      return;
    }
    console.log('new user', this.userFormGroup?.value);
    this.showAddUserDialog = false
    this.insertHttp.addnewUser$(this.userFormGroup?.value).pipe(
      tap(ans => console.log('ans', ans)),
      tap(_ => this.getAllUsers())
    ).subscribe()
    this.restart()
  }

  //----------------------------------------------------------------------- מחיקת משתמש 

  deleteUser(u: User) {
    this.setUser = u
    this.showDeleteUserDialog = true
  }

  HideDeleteUserDialog() {
    this.showDeleteUserDialog = false;
    this.setUser = undefined
  }

  saveDeleteUserDialog() {
    console.log(this.setUser);
    this.showDeleteUserDialog = false;
    this.deleteHttp.deleteOneUser$(this.setUser?._id ? this.setUser?._id : undefined).pipe(
      tap(ans => console.log('answer:', ans)),
      tap(_ => this.getAllUsers()),
    ).subscribe()
    console.log('id of oneUser', this.setUser?._id);
    console.log('id of userrrrrrrrrrrrrr', this.selectHttp.getUser()._id);
    // if (this.setUser?._id == this.selectHttp.getUser()._id)
    //   this.selectHttp.changeUser({
    //     firstName: '',
    //     lastName: '',
    //     _id: '',
    //     idNumber: '',
    //     phone: '',
    //     mailAddress: '',
    //     password: '',
    //     rule: ''
    //   })
    this.setUser = undefined
  }

  //----------------------------------------------------------------------- עדכון משתמש 

  updateUser(u: User) {
    this.setUser = u
    this.userFormGroup = this.formBuilder.group({
      firstName: this.setUser.firstName,
      lastName: this.setUser.lastName,
      idNumber: this.setUser.idNumber,
      phone: this.setUser.phone,
      mailAddress: this.setUser.mailAddress,
      password: this.setUser.password,
      rule: this.setUser.rule
    })
    this.showUpdateUserDialog = true
  }

  HideUpdateUserDialog() {
    this.showUpdateUserDialog = false
    this.setUser = undefined
    this.restart()
  }

  saveUpdateUserDialog() {
    console.log('user in update', this.userFormGroup?.value);
    this.showUpdateUserDialog = false
    this.updateHttp.updateUser$(this.setUser?._id ? this.setUser?._id : '', this.userFormGroup?.value).pipe(
      tap(ans => console.log('answer:', ans)),
      tap(_ => this.getAllUsers()),
    ).subscribe()
    console.log('id of oneUser', this.setUser?._id);
    console.log('id of userrrrrrrrrrrrrr', this.selectHttp.getUser()._id);
    if (this.setUser?._id == this.selectHttp.getUser()._id) {
      this.userFromUserFormGroup = this.userFormGroup?.value;
      this.userFromUserFormGroup._id = this.setUser?._id
      this.selectHttp.changeUser(this.userFromUserFormGroup)
    }
    this.setUser = undefined
    this.restart()
  }

}
