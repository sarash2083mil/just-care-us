import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewAllUsersComponent } from './view-all-users.component';
import {AngularDesignModule} from 'src/app/design.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [ViewAllUsersComponent],
  imports: [
    CommonModule,
    AngularDesignModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports:[ViewAllUsersComponent]
})
export class ViewAllUsersModule { }
