import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AbsencesClassComponent } from './absences-class.component';
import { AppRoutingModule } from 'src/app/app-routing.module';
import {AngularDesignModule} from 'src/app/design.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [AbsencesClassComponent],
  imports: [
    CommonModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AngularDesignModule
  ],
  exports:[AbsencesClassComponent]
})
export class AbsencesClassModule { }
