import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NEVER, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { SelectService } from 'src/app/services/select.service';
import { student } from 'src/app/types/student';

@Component({
  selector: 'app-absences-class',
  templateUrl: './absences-class.component.html',
  styleUrls: ['./absences-class.component.scss']
})
export class AbsencesClassComponent implements OnInit {

  showChoiceDatesDialog: boolean = false
  showChoiceDatesDialogToOneStudent:boolean=false
  startDate: FormControl = new FormControl(new Date())
  endDate: FormControl = new FormControl(new Date())
  studentByClassArr$: Observable<student[]> = NEVER
  nameClass: string = ''
  firstName: string = ''
  lastName: string = ''
  _id: string = ''

  constructor(private route: ActivatedRoute, private router: Router, private selectHttp: SelectService) {
    this.route.params.subscribe((params: Params) => {
      this.nameClass = params.nameClass;
      console.log('nameClass', this.nameClass);
    });
  }

  ngOnInit(): void {
    this.studentByClassArr$ = this.selectHttp.getStudentsByClass$(this.nameClass).pipe(
      tap(s => console.log(s))
    )
  }

  viewAbsencesToStudent(firstName: string, lastName: string, _id: string) {
    this.showChoiceDatesDialogToOneStudent = true
    this.firstName=firstName
    this.lastName=lastName
    this._id=_id
  }

  // goToAbsencesStudent() {
  //   console.log("firstName", this.firstName);
  //   console.log("lastName", this.lastName);
  //   console.log("id", this._id);
  //   this.router.navigate([this.router.url.search('managerMenu') == 1 ?
  //     'managerMenu/absencesStudent/' + this.firstName + '/' + this.lastName + '/' + this._id + '/' + this.nameClass:
  //     'secretaryMenu/absencesStudent/' + this.firstName + '/' + this.lastName + '/' + this._id + '/' + this.nameClass])
  // }

  printToAllStudentsInClass() {
    this.showChoiceDatesDialog = true
  }

  sendDates() {
    this.showChoiceDatesDialog = false
    console.log('startDate', this.startDate.value);
    console.log('endDate', this.endDate.value);
    let d1 = new Date(this.startDate.value)
    let d2 = new Date(this.endDate.value)
    console.log('d1', d1);
    console.log('d2', d2);
    this.router.navigate([this.router.url.search('managerMenu') == 1 ?
      'managerMenu/printAbsences/' + d1 + '/' + d2 + '/' + this.nameClass : 'secretaryMenu/printAbsences/' + d1 + '/' + d2 + '/' + this.nameClass])
  }

  hideChoiceDatesDialog() {
    this.showChoiceDatesDialog = false
  }

  sendDatesToOneStudent(){
    this.showChoiceDatesDialogToOneStudent=false
    console.log('startDate', this.startDate.value);
    console.log('endDate', this.endDate.value);
    let d1 = new Date(this.startDate.value)
    let d2 = new Date(this.endDate.value)
    console.log('d1', d1);
    console.log('d2', d2);
    this.router.navigate([this.router.url.search('managerMenu') == 1 ?
      'managerMenu/absencesStudent/' + this.firstName + '/' + this.lastName + '/' + this._id + '/'
       + this.nameClass + '/' + d1 + '/' + d2:
      'secretaryMenu/absencesStudent/' + this.firstName + '/' + this.lastName + '/' + this._id + '/' 
      + this.nameClass + '/' + d1 + '/' + d2])
    
  }

  hideChoiceDatesDialogToOneStudent(){
    this.showChoiceDatesDialogToOneStudent=false
  }

}




