import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EndOfYearComponent } from './end-of-year.component';

describe('EndOfYearComponent', () => {
  let component: EndOfYearComponent;
  let fixture: ComponentFixture<EndOfYearComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EndOfYearComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EndOfYearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
