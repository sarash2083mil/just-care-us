import { Component, OnInit } from '@angular/core';
import { NEVER } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { DeleteService } from 'src/app/services/delete.service';

@Component({
  selector: 'app-end-of-year',
  templateUrl: './end-of-year.component.html',
  styleUrls: ['./end-of-year.component.scss']
})
export class EndOfYearComponent implements OnInit {

  constructor(private deleteServer: DeleteService) { }
  
  showDeleteSchoolDialog=false
  Deleted:boolean=false
  noDeleted:boolean=false

  ngOnInit(): void {
  }

  deleteAllSchool() {
    this.showDeleteSchoolDialog=true
  }

  HideDeleteSchoolDialog(){
    this.showDeleteSchoolDialog=false
  }

  saveDeleteSchoolDialog(){
    this.showDeleteSchoolDialog=false
    this.deleteServer.deleteAllSchool$().pipe(
      tap(answer => console.log('the answer:', answer)),
      tap(answer =>answer?this.Deleted=true:this.noDeleted=true),
      tap(answer => console.log('this.Deleted:', this.Deleted)),
      tap(answer => console.log('this.noDeleted:', this.noDeleted)),
    ).subscribe()
  }

  }
