import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PasswordResetComponent } from './password-reset.component';
import { AngularDesignModule } from 'src/app/design.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [PasswordResetComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularDesignModule
  ],
  exports:[PasswordResetComponent]
})
export class PasswordResetModule { }
