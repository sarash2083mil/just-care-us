import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { tap } from 'rxjs/operators';
import { SelectService } from 'src/app/services/select.service';
import { User } from 'src/app/types/user';

@Component({
  selector: 'app-password-reset',
  templateUrl: './password-reset.component.html',
  styleUrls: ['./password-reset.component.scss']
})
export class PasswordResetComponent implements OnInit {

  formGroup!: FormGroup;
  user: User = {
    firstName: '',
    lastName: '',
    _id: '',
    idNumber: '',
    phone: '',
    mailAddress: '',
    password: '',
    rule: ''
  }

  constructor(private formBuilder: FormBuilder, private route: ActivatedRoute
    , private router: Router, private selectHttp: SelectService) { }

  mail: string = ""

  ngOnInit() {
    this.formGroup = this.formBuilder.group({
      password: ['', Validators.required]
    });
    this.route.params.subscribe((params: Params) => {
      this.mail = params.mail;
      console.log(this.mail, this.mail);
    });
  }

  sendNewPassword() {
    this.selectHttp.getRuleByMail$(this.mail, this.formGroup?.value.password).pipe(
      tap(u => console.log("!!!user!!!!", u)),
      tap(u => this.user = u),
      tap(_ => localStorage.setItem('rule', this.user?.rule)),
      tap(_ => localStorage.setItem('currentUser', JSON.stringify(this.user))),
      tap(_ => this.user?this.selectHttp.changeUser(this.user):this.router.navigate([''])),
      tap(_ => this.user?.rule === "מנהל" ?
        this.router.navigate(['managerMenu']) :
        this.user?.rule === "מורה" ?
          this.router.navigate(['teacherMenu']) :
          this.router.navigate(['secretaryMenu']))
    ).subscribe()
  }
}

