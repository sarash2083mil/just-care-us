import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AbsencesStudentComponent } from './absences-student.component';



@NgModule({
  declarations: [AbsencesStudentComponent],
  imports: [
    CommonModule
  ],
  exports:[AbsencesStudentComponent]
})
export class AbsencesStudentModule { }
