import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NEVER, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { SelectService } from 'src/app/services/select.service';
import { student } from 'src/app/types/student';
import { Location } from '@angular/common';

@Component({
  selector: 'app-absences-student',
  templateUrl: './absences-student.component.html',
  styleUrls: ['./absences-student.component.scss']
})
export class AbsencesStudentComponent implements OnInit {

  theAbsences$: Observable<any[]> = NEVER
  @Input() student: student | undefined
  printOneStudent$: Observable<student> = NEVER
  firstName: string = ''
  lastName: string = ''
  _id: string = ''
  startDate: Date | undefined
  endDate: Date | undefined
  nameClass: string = ''
  days = ['ראשון', 'שני', 'שלישי', 'רביעי', 'חמישי', 'שישי', 'שבת']

  constructor(private route: ActivatedRoute, private router: Router, private selectHttp: SelectService, private _location: Location) {
    this.route.params.subscribe((params: Params) => {
      console.log('params', params);
      this.firstName = params.firstName;
      this.lastName = params.lastName;
      this._id = params._id;
      this.nameClass = params.nameClass;
      this.startDate = params.startDate;
      this.endDate = params.endDate;
      console.log('firstName', this.firstName);
      console.log('lastName', this.lastName);
      console.log('_id', this._id);
      console.log('nameClass', this.nameClass);
      console.log('startDate', this.startDate);
      console.log('endDate', this.endDate);
    });
  }

  ngOnInit() {
    console.log('studentFromFather', this.student);
    if (this.student == undefined) {
      console.log('one student');
      this.selectHttp.getAbsencesOfStudentById$(this._id, this.startDate, this.endDate).pipe(
        tap(theAbsences => {
          console.log('theAbsences', theAbsences)
        } )
      ).subscribe((s) => {
        console.log(s);
        this.student = s;
      })
    }
  }

  goToClass() {
    this._location.back();
  }

}
