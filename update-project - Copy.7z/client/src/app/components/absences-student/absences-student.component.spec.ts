import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AbsencesStudentComponent } from './absences-student.component';

describe('AbsencesStudentComponent', () => {
  let component: AbsencesStudentComponent;
  let fixture: ComponentFixture<AbsencesStudentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AbsencesStudentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AbsencesStudentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
