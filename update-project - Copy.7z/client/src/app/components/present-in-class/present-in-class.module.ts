import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PresentInClassComponent } from './present-in-class.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularDesignModule } from '../../design.module';
//const MAT_CHECKBOX_DEFAULT_OPTIONS: InjectionToken<MatCheckboxDefaultOptions>;


@NgModule({
  declarations: [
    PresentInClassComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularDesignModule,
  ],
  // providers: [
  //   {provide: MAT_CHECKBOX_DEFAULT_OPTIONS, useValue: { clickAction: 'noop' } }
  // ],
  exports:[
    PresentInClassComponent
  ]
})
export class PresentInClassModule { }
