import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PresentInClassComponent } from './present-in-class.component';

describe('PresentInClassComponent', () => {
  let component: PresentInClassComponent;
  let fixture: ComponentFixture<PresentInClassComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PresentInClassComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PresentInClassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

