import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NEVER, Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { InsertService } from 'src/app/services/insert.service';
import { SelectService } from 'src/app/services/select.service';
import { student } from 'src/app/types/student';

@Component({
  selector: 'app-present-in-class',
  templateUrl: './present-in-class.component.html',
  styleUrls: ['./present-in-class.component.scss']
})
export class PresentInClassComponent implements OnInit {

  // @Output() myUbsenseStudents: EventEmitter<any> = new EventEmitter();

  // present: FormControl[] = [];
  // studentAbsenceInClass:student[]=[]
  // studentInClassFromFather: student[] = []

  // constructor(private selectHttp: SelectService) { }

  // getStudentInClass(studentInClassFromFather: student[]) {
  //   for (var i = 0; i < studentInClassFromFather.length; i++) {
  //     this.present[i] = new FormControl()
  //   }
  //   console.log('studentInClassFromFather', studentInClassFromFather)
  //   this.studentInClassFromFather = studentInClassFromFather
  // }

  // sendMessage() {
  //   for (var i = 0; i < this.studentInClassFromFather.length; i++) {
  //     console.log("this.present[" + i + "]", this.present[i].value);
  //     this.studentInClassFromFather[i].presentToday = this.present[i].value
  //     if(this.studentInClassFromFather[i].presentToday ==null||
  //       this.studentInClassFromFather[i].presentToday ==false)
  //       this.studentAbsenceInClass.push(this.studentInClassFromFather[i])
  //   }
  //   this.myUbsenseStudents.emit(this.studentAbsenceInClass)
  // }
  atLeastOneChoosen = false;
  areAllExists = false;
  checkboxColor = "blue";
  present: FormControl[] = [];
  studentByClassArr$: Observable<student[]> = NEVER
  studentByClassArr: student[] = []
  nameClass: string = '';
  wasMessageSent = false;

  constructor(private route: ActivatedRoute, private insertHttp: InsertService,
    private router: Router, private selectHttp: SelectService) {
    this.route.params.subscribe((params: Params) => {
      this.nameClass = params.nameClass;
      console.log(this.nameClass);
    });
  }
  ngOnInit() {
    this.getStudents();
  }

  getStudents() {
    this.studentByClassArr$ = this.selectHttp.getStudentsByClass$(this.nameClass).pipe(
      tap(s => console.log(s)),
      tap(s => this.studentByClassArr = s),
      tap(s => this.buildControls(s))
    )
    this.studentByClassArr$.subscribe(s=>this.studentByClassArr = s);
  }


  buildControls(studentsList: student[]) {
    for (var i = 0; i < studentsList.length; i++) {
      const currStudent = studentsList[i];
      let absencesTodayArr = [];
      if (currStudent.theAbsences?.length)
        absencesTodayArr = currStudent?.theAbsences.filter((abs) => {
          const theDate: string = abs["theDate"];
          const myArray = theDate.split(".");
          const currentDate = new Date();
          if (myArray[0] == currentDate.getDate().toString()
            && myArray[1] == (currentDate.getMonth() + 1).toString()
            && myArray[2] == currentDate.getFullYear().toString())
            return abs;
          return null;
        });

      //this.present[i] = new FormControl(!absencesTodayArr?.length);
      studentsList[i].presentToday = !absencesTodayArr?.length || false;
      this.areAllExists = this.areAllChecked();
      console.log(this.present[i]);
    }
  }

  markStudent(value: boolean) {
    //למנוע עדכון לתלמיד כך שיהיו לו 2 אנטריס ליום במערך חסורים חשוב מאד ! 
  if(!value)
     this.areAllExists = false;
   else 
   this.areAllExists = this.areAllChecked();
  }

  areAllChecked(){
    const someArentChecked =  this.studentByClassArr.some((s)=>{
      return s.presentToday ==false;
    });
    // this.present.filter((i)=> { return !i.value});
   if(someArentChecked)
      return false;
    return true;
  }

  effectAllStudents(){
    this.areAllExists = !this.areAllExists;
    this.studentByClassArr.forEach((s)=>{
      s.presentToday = this.areAllExists;
    });
    // this.present.forEach(i => {
    //   let v = i.value;
    //   v = this.areAllExists;
    //   i.setValue(v);
    // });
  }

  sendMessage() {
    if (this.wasMessageSent) {
      alert("ניתן לסמן ולשלוח הודעות נוכחות אחת ליום, לכיתה");
      return;
    }
    // for (var i = 0; i < this.studentByClassArr.length; i++) {
    //   console.log("this.present[" + i + "]", this.present[i].value);
    //   this.studentByClassArr[i].presentToday = this.present[i].value;
      
    // }

    console.log('studentByClassArr', this.studentByClassArr);
    const missedStudents = this.studentByClassArr.filter(s => s.presentToday == null || s.presentToday == false)
    console.log('studentAbsenceInClass', missedStudents);
    if (!missedStudents.length)
      return;

    this.wasMessageSent = true;

    this.insertHttp.absencesToday$(this.studentByClassArr).pipe(
      tap(ans => console.log(ans)),
    ).subscribe((res) => {
      alert("ההודעות נשלחו בהצלחה להורי התלמידים החסרים");
      //this.getStudents();
      //popup
    })
  }

}

