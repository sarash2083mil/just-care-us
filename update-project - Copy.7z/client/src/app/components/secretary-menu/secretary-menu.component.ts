import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SelectService } from 'src/app/services/select.service';
import { User } from 'src/app/types/user';

@Component({
  selector: 'app-secretary-menu',
  templateUrl: './secretary-menu.component.html',
  styleUrls: ['./secretary-menu.component.scss']
})
export class SecretaryMenuComponent implements OnInit {

  user: User | undefined

  constructor(private router: Router, private selectHttp: SelectService) { }

  ngOnInit(): void {
   this.user = this.selectHttp.getUser()
  }

  menu(path: string) {
    this.router.navigate([`secretaryMenu/${path}`])
  }
}
