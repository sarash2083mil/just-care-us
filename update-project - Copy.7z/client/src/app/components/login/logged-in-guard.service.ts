import { getMissingNgModuleMetadataErrorData } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { SelectService } from 'src/app/services/select.service';
import { User } from 'src/app/types/user';
import { LoginComponent } from './login.component';
import { MatDialog } from '@angular/material/dialog';

@Injectable({ providedIn: 'root' })
export class LoggedInGuardService implements CanActivate {

    constructor(private router: Router, private selectService: SelectService,private dialog: MatDialog,) { }

    canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
        let user: User;
        let userFromStorage:any = localStorage.getItem('currentUser');
        if (userFromStorage)
            userFromStorage = JSON.parse(userFromStorage);
        //if user in th system

        if (userFromStorage && (!Array.isArray(userFromStorage) || userFromStorage.length) ){
            user = new User(userFromStorage);
            //if user wasnt initialized
            let u = this.selectService.getUser();
            if (!u?.firstName?.length) {
                this.selectService.setUser(user);
            }

            return true;
        }


        // if (localStorage.getItem('rule') == 'מנהל' ||
        //     localStorage.getItem('rule') == 'מזכירה' ||
        //     localStorage.getItem('rule') == 'מורה') {
        //     //localStorage.removeItem('rule')
        //     console.log("localStorage.getItem('rule')", localStorage.getItem('rule'));
        //     return true;
        // }
        localStorage.removeItem('rule');
        console.log("localStorage.getItem('rule')", localStorage.getItem('rule'));
        this.router.navigate(['home']);
        // this.dialog.open(LoginComponent, {
        //       data: {
        //         message: "Error!!!"
        //       }
        // });
        return false;
        }
}

//note to this guard - on logout component the removing of user supposed to be
