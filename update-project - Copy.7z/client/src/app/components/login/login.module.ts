import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EndOfYearModule } from '../end-of-year/end-of-year.module';
import { AngularDesignModule } from 'src/app/design.module';
import { AppRoutingModule } from 'src/app/app-routing.module';





@NgModule({
  declarations: [
    LoginComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    EndOfYearModule,
    AppRoutingModule,
    AngularDesignModule
  ],
  exports: [
    LoginComponent
  ],
})
export class LoginModule { }

