import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/types/user';
import { map, tap } from 'rxjs/operators';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NEVER, Observable } from 'rxjs';
import { SelectService } from 'src/app/services/select.service';
import { SendMessageService } from 'src/app/services/send-message.service';
import { environment } from 'src/environments/environment';
import { NewUserComponent } from '../new-user/new-user.component';
import { MatDialog } from '@angular/material/dialog';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  image = environment.imagePath
  showSendEmail: boolean = false
  allUsers$: Observable<User[]> = NEVER
  mailAddress: FormControl = new FormControl()
  showforgetPasswordDialog: boolean = false
  mouseoverLogin!: boolean;
  formGroup!: FormGroup;
  userToCheck: any | undefined
  userArr$: Observable<User[]> = NEVER;
  userArr: User[] | undefined
  loginFailed = false;
  user: User = {
    firstName: '',
    lastName: '',
    _id: '',
    idNumber: '',
    phone: '',
    mailAddress: '',
    password: '',
    rule: ''
  }

  constructor(private formBuilder: FormBuilder, private selectHttp: SelectService,
    private sendMessageHttp: SendMessageService, private router: Router, private dialog: MatDialog) { }

  ngOnInit() {
    this.formGroup = this.formBuilder.group({
      idNumber: ['', Validators.required],
      password: ['', Validators.required]
    });
    this.allUsers$ = this.selectHttp.getAllUsers$().pipe(
      tap(users => console.log('allUsers', users))
    )
  }

  login() {
    console.log("login")
    const { idNumber, password } = this.formGroup.value;
    console.log('idNumber', idNumber)
    console.log('password', password)
    // this.CheckUsers()
  }

  CheckUsers() {
    console.log('CheckUsers');
    this.userToCheck = {
      idNumber: this.formGroup.value.idNumber,
      password: this.formGroup.value.password
    }
    this.selectHttp.checkUsers$(this.userToCheck).pipe(
      tap(u => console.log("!!!user!!!!", u)),
      tap(u => this.user = u),
      tap(_ => localStorage.setItem('rule', this.user.rule)),
      tap(_ => localStorage.setItem('currentUser', JSON.stringify(this.user))),
      tap(_ => this.selectHttp.changeUser(this.user)),
      tap(_ => this.user.rule === "מנהל" ?
        this.router.navigate(['managerMenu']) :
        this.user.rule === "מורה" ?
          this.router.navigate(['teacherMenu']) :
          this.router.navigate(['secretaryMenu']))
    ).subscribe((user:User|any) => {
      if(!user.length){
        this.onLoginFailed();
        return;
      }
    
      console.log(user);
      this.selectHttp.user = user;
      this.onLoginSuccess();
    }
    )
  }

  register() {
    console.log("register");
    this.dialog.open(NewUserComponent, {
      data: {
        message: "Error!!!"
      }
    });
    // this.router.navigate(['login/newUser'])
  }

  forgetPassword() {
    console.log("forgetPassword");
    this.mailAddress = new FormControl()
    this.showforgetPasswordDialog = true
  }

  hideforgetPasswordDialog() {
    this.showforgetPasswordDialog = false
  }

  sendNewPassword() {
    console.log('שולח מייל', this.mailAddress.value);
    this.showSendEmail = true
    this.sendMessageHttp.resetPassword$(this.mailAddress.value).pipe(
      tap(ans => console.log('the answer', ans))
    ).subscribe()
    this.showforgetPasswordDialog = false
  }

  onLoginFailed(){
    this.loginFailed = true;
  }

  onLoginSuccess() {
    this.loginFailed = false;
    this.dialog.closeAll();
  }
}




