import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SelectService } from 'src/app/services/select.service';
import { User } from 'src/app/types/user';

@Component({
  selector: 'app-teacher-menu',
  templateUrl: './teacher-menu.component.html',
  styleUrls: ['./teacher-menu.component.scss']
})
export class TeacherMenuComponent implements OnInit {

  user: User | undefined
  selected = '';

  constructor(private router: Router, private selectHttp:SelectService) { }

  ngOnInit(): void {
    this.user = this.selectHttp.getUser()
  }

  menu(path: string){
    this.selected = path;
    this.router.navigate([`teacherMenu/${path}`])
  }
}
