import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AttendanceMarkingComponent } from './attendance-marking.component';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { PresentInClassModule } from '../present-in-class/present-in-class.module';
// import { ChoiceClassModule } from '../choice-class/choice-class.module';
// import { InManuallyModule } from '../in-manually/in-manually.module';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AttendanceMarkingComponent
  ],
  imports: [
    CommonModule,
    AppRoutingModule,
    // ChoiceClassModule,
    BrowserModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    // PresentInClassModule
  ],
  exports: [
    AttendanceMarkingComponent
  ]
})
export class AttendanceMarkingModule { }
