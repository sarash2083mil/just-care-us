import { Component, ElementRef, OnInit, TemplateRef, ViewChild, ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { NEVER, Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { SelectService } from 'src/app/services/select.service';
import { student } from 'src/app/types/student';
import { PresentInClassComponent } from '../present-in-class/present-in-class.component';

@Component({
  selector: 'app-attendance-marking',
  templateUrl: './attendance-marking.component.html',
  styleUrls: ['./attendance-marking.component.scss']
})
export class AttendanceMarkingComponent implements OnInit {

  classesArr$: Observable<string[]> = NEVER

  // @ViewChild('childPresentInClass') myChildPresentInClass!: PresentInClassComponent;

  // choiceClass:string=''
  // studentInClass: student[] = []
  // constructor(private selectHttp: SelectService,private vref: ViewContainerRef) { }
  // myChildChoiceClass(myClass: string){
  //   console.log("in myChildChoiceClass");
  //   this.choiceClass=myClass
  //   this.selectHttp.getStudentsByClass$(myClass).pipe(
  //     map(s => this.myChildPresentInClass?.getStudentInClass(s))
  //   ).subscribe()
  // }

  // myChildUbsenseStudents(studentAbsenceInClass: student[]) {
  //   console.log("studentAbsenceInClass in father", studentAbsenceInClass);
  // }

  constructor(private selectHttp: SelectService, private router: Router) { }

  ngOnInit(): void {
    this.selectAllClasses()
  }

  selectAllClasses() {
    this.classesArr$ = this.selectHttp.getClasses$().pipe(
      tap(c => console.log('classes:', c))
    )
  }

  viewClass(nameClass: string) {
    this.router.navigate([this.router.url.search('managerMenu') == 1 ?
      'managerMenu/presentInClass/' + nameClass :
      this.router.url.search('secretaryMenu') == 1 ?
        'secretaryMenu/presentInClass/' + nameClass :
        'teacherMenu/presentInClass/' + nameClass
    ])



  }
}




