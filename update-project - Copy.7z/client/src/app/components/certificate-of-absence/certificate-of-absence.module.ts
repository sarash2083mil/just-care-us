import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CertificateOfAbsenceComponent } from './certificate-of-absence.component';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from 'src/app/app-routing.module';
import {AngularDesignModule} from 'src/app/design.module';



@NgModule({
  declarations: [CertificateOfAbsenceComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    AngularDesignModule
  ],
  exports:[CertificateOfAbsenceComponent]
})
export class CertificateOfAbsenceModule { }
