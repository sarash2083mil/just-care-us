import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CertificateOfAbsenceComponent } from './certificate-of-absence.component';

describe('CertificateOfAbsenceComponent', () => {
  let component: CertificateOfAbsenceComponent;
  let fixture: ComponentFixture<CertificateOfAbsenceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CertificateOfAbsenceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CertificateOfAbsenceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
