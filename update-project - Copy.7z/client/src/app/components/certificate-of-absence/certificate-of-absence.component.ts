import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { NEVER, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { SelectService } from 'src/app/services/select.service';

@Component({
  selector: 'app-certificate-of-absence',
  templateUrl: './certificate-of-absence.component.html',
  styleUrls: ['./certificate-of-absence.component.scss']
})
export class CertificateOfAbsenceComponent implements OnInit {

  showChoiceDatesDialog: boolean = false
  startDate: FormControl = new FormControl(new Date())
  endDate: FormControl = new FormControl(new Date())
  classesArr$: Observable<string[]> = NEVER;
  areClassesExists = false;

  constructor(private selectHttp: SelectService, private router: Router) { }

  // שליפת כל הכיתות
  ngOnInit(): void {
    this.classesArr$ = this.selectHttp.getClasses$().pipe(
      tap(c => {
        console.log('classes:', c);
        this.areClassesExists = c && c.length != null;
      }),
    )
  }

  viewClass(nameClass: string) {
    console.log(nameClass);
    this.router.navigate([this.router.url.search('managerMenu') == 1 ?
      'managerMenu/absencesClass/' + nameClass : 'secretaryMenu/absencesClass/' + nameClass])
  }

  printToAllStudents() {
    this.showChoiceDatesDialog = true
  }

  sendDates() {
    this.showChoiceDatesDialog = false
    console.log('startDate', this.startDate.value);
    console.log('endDate', this.endDate.value);

    let d1 = new Date(this.startDate.value)
    let d2 = new Date(this.endDate.value)

    // let d1=this.startDate.value
    // let d2=this.endDate.value
    // let d1=new Date(this.startDate.value)
    // let d2=new Date(this.endDate.value)


    // let d1 = ''
    // let d2 = ''

    // new Date(this.startDate.value).getDate() < 10 ?
    //   d1 += '0' + new Date(this.startDate.value).getDate() + '.' :
    //   d1 += new Date(this.startDate.value).getDate() + '.'

    // new Date(this.startDate.value).getMonth() < 10 ?
    //   d1 += '0' + (new Date(this.startDate.value).getMonth() + 1) + '.' :
    //   d1 += '' + (new Date(this.startDate.value).getMonth() + 1) + '.'

    // d1 += new Date(this.startDate.value).getFullYear()

    // new Date(this.endDate.value).getDate() < 10 ?
    //   d2 += '0' + new Date(this.endDate.value).getDate() + '.' :
    //   d2 += new Date(this.endDate.value).getDate() + '.'
    // new Date(this.endDate.value).getMonth() < 10 ?
    //   d2 += '0' + (new Date(this.endDate.value).getMonth() + 1) + '.' :
    //   d2 += '' + (new Date(this.endDate.value).getMonth() + 1) + '.'
    // d2 += new Date(this.endDate.value).getFullYear()

    // let d1=new Date(this.startDate.value).toLocaleDateString()
    // let d2=new Date(this.endDate.value).toLocaleDateString()

    console.log('d1', d1);
    console.log('d2', d2);

    this.router.navigate([this.router.url.search('managerMenu') == 1 ?
      'managerMenu/printAbsences/' + d1 + '/' + d2 + '/allSchool' : 'secretaryMenu/printAbsences/' + d1 + '/' + d2 + '/allSchool'])
  }

  hideChoiceDatesDialog() {
    this.showChoiceDatesDialog = false
  }
}
