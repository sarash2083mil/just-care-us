import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClassesComponent } from './classes.component';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { AddClassModule } from '../add-class/add-class.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {AngularDesignModule} from 'src/app/design.module';

@NgModule({
  declarations: [
    ClassesComponent
  ],
  imports: [
    CommonModule,
    AppRoutingModule,
    AddClassModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    AngularDesignModule
  ],
  exports:[ClassesComponent]
})
export class ClassesModule { }
