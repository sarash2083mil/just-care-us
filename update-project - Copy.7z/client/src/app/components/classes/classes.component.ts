import { AfterViewInit, Component, OnInit, TemplateRef, ViewChild, ViewContainerRef } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { NEVER, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { DeleteService } from 'src/app/services/delete.service';
import { InsertService } from 'src/app/services/insert.service';
import { SelectService } from 'src/app/services/select.service';
import { UpdateService } from 'src/app/services/update.service';
import { student } from 'src/app/types/student';
import * as XLSX from 'xlsx';


@Component({
  selector: 'app-classes',
  templateUrl: './classes.component.html',
  styleUrls: ['./classes.component.scss']
})
export class ClassesComponent implements OnInit {

  studentArr: student[] = []
  file: any;
  fileList: any = undefined;
  listKeys: string[] | undefined;
  arrayBuffer: any;
  arr: any;
  selectedTypeAdd: string = ''
  typeAdd = [
    { name: "הוספה ידנית",key:"manual"},
    { name: "הוספה מקובץ אקסל" ,key:"excel"}
  ]
  howToAdd: string = ''
  nameAddNewClass: FormControl = new FormControl()
  numStudents: FormControl = new FormControl()
  classesArr$: Observable<string[]> = NEVER
  classesArr: string[] = []
  showAddClassDialog: boolean = false;
  showUpdateClassDialog: boolean = false
  showDeleteClassDialog: boolean = false
  showExistsAddClassDialog: boolean = false
  ShowExistsUpdateClassDialog: boolean = false
  oldClass: string = ''
  newClass: string = ''

  constructor(private selectHttp: SelectService, private updatetHttp: UpdateService
    , private insertHttp: InsertService, private deleteHttp: DeleteService, private router: Router) { }

  ngOnInit(): void {
    this.selectAllClasses()
  }

  //----------------------------------------------------------------------- פונקציות אוניברסליות

  // שליפת כל הכיתות
  selectAllClasses() {
    this.classesArr$ = this.selectHttp.getClasses$().pipe(
      tap(c => console.log('classes:', c)),
      tap(c => this.classesArr = c)
    )
  }


  // בדיקה אם הכיתה כבר קיימת במערכת
  checkedNoAlreadyClass(myClass: string) {
    console.log('in checkedNoAlreadyClass')
    console.log('this.classesArr',this.classesArr)
    console.log('already', this.classesArr.filter(a => a == myClass)?.length);
    if (this.classesArr.filter(a => a == myClass)?.length == 0)
      return true
    return false
  }

  //----------------------------------------------------------------------- הוספת כיתה

  // הצגת דיאלוג הוספת כיתה חדשה
  addClass() {
    this.showAddClassDialog = true;
  }

  // בחירת אופן הוספת הכיתה: ידני או מקובץ אקסל
  how(event: any) {
    console.log(event.value.key);
    this.howToAdd = event.value.key
    if (this.howToAdd == 'manual')
      this.fileList = undefined
  }

  // ביטול הוספת כיתה חדשה
  hideAddClassDialog() {
    this.showAddClassDialog = false;
    this.nameAddNewClass = new FormControl()
    this.numStudents = new FormControl()
    this.howToAdd = ''
  }

  // שמירת הוספת כיתה חדשה
  saveAddClassDialog() {
    this.showAddClassDialog = false;
    if (this.checkedNoAlreadyClass(this.nameAddNewClass.value)) {
      this.howToAdd == 'manual' ?
        this.router.navigate([this.router.url.search('managerMenu') ?
          'managerMenu/addClass/' + this.nameAddNewClass.value + '/' + this.numStudents.value
          : 'secretaryMenu/addClass/' + this.nameAddNewClass.value + '/' + this.numStudents.value])
        : this.addFromExel()
      this.nameAddNewClass = new FormControl()
      this.numStudents = new FormControl()
      this.howToAdd = ''
    }
    else {
      this.showExistsAddClassDialog = true
      this.numStudents.setValue('')
    }
  }

  // בחירת קובץ אקסל להוספת כיתה חדשה
  choosefile(event: any) {
    console.log('in choosefile');
    this.file = event.target.files[0];
    const fileReader = new FileReader();
    fileReader.readAsArrayBuffer(this.file);
    fileReader.onload = () => {
      this.arrayBuffer = fileReader.result;
      const data = new Uint8Array(this.arrayBuffer); // הקודים של התווים
      const arr = new Array();
      for (let i = 0; i < data.length; ++i) {
        arr[i] = String.fromCharCode(data[i]); // מתרגם לתווים
      }
      const bstr = arr.join(''); // נכתב כקטע
      const workbook = XLSX.read(bstr, { type: 'binary', cellDates: true });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      this.fileList = XLSX.utils.sheet_to_json(worksheet, { raw: true }); // את השורה הראשונה הוא מחשיב ככותרת
      this.listKeys = Object.keys(this.fileList[0]);
      console.log("fileList", this.fileList);
      for(let i=0; i<this.fileList.length;i++)
      {
        // let newStudent:student={
        //   firstName: this.fileList[i]['שם פרטי'],
        //   lastName: this.fileList[i]['שם משפחה'],
        //   idNumber: this.fileList[i]['מספר זהות'],
        //   gender: this.fileList[i]['מין'],
        //   phone1: this.fileList[i]['פלאפון 1'],
        //   phone2: this.fileList[i]['פלאפון 2'],
        //   address: this.fileList[i]['כתובת'],
        //   remarks: this.fileList[i]['הערות'],
        //   class: this.nameAddNewClass.value
        // }
        this.studentArr.push({
          firstName: this.fileList[i]['שם פרטי'],
          lastName: this.fileList[i]['שם משפחה'],
          idNumber: this.fileList[i]['מספר זהות'],
          gender: this.fileList[i]['מין'],
          phone1: this.fileList[i]['פלאפון 1'],
          phone2: this.fileList[i]['פלאפון 2'],
          address: this.fileList[i]['כתובת'],
          remarks: this.fileList[i]['הערות'],
          class: this.nameAddNewClass.value
        })
      }
      console.log(this.studentArr);
    };
  }

  // הוספת כיתה חדשה מקובץ אקסל
  addFromExel() {
    this.insertHttp.addNewClass$(this.studentArr).pipe(
      tap(ans => console.log(ans)),
      tap(_=> this.selectAllClasses())
    ).subscribe()
  }

  // ביטול הוספת שם אחר אם שם הכיתה החדשה כבר קיים במערכת
  hideExistsAddClassDialog() {
    this.showExistsAddClassDialog = false
    this.nameAddNewClass.setValue('')
    this.howToAdd = ''
  }


  // שמירת הוספת שם אחר אם שם הכיתה החדשה כבר קיים במערכת
  addOtherClassDialog() {
    this.showExistsAddClassDialog = false
    this.nameAddNewClass.setValue('')
    this.howToAdd = ''
    this.showAddClassDialog = true
  }

  //----------------------------------------------------------------------- הצגת כל הכיתות

  // מעביר לניתוב אחר שמציג את פרטי הכיתה הנבחרת
  viewClass(nameClass: string) {
    this.router.navigate([this.router.url.search('managerMenu') == 1 ?
      'managerMenu/viewClass/' + nameClass : 'secretaryMenu/viewClass/' + nameClass])
  }

  // הצגת הדיאלוג של עדכון/ מחיקת הכיתה-תלוי בבחירת המשתמש
  yourChoice(choice: string, nameClass: string) {
    choice == 'updateClass' ?
      this.showUpdateClassDialog = true :
      this.showDeleteClassDialog = true;
    this.oldClass = nameClass
  }

  //----------------------------------------------------------------------- עדכון שם הכיתה

  //  ביטול עדכון שם הכיתה
  hideUpdateClassDialog() {
    this.showUpdateClassDialog = false;
    this.newClass = ''
    this.oldClass = ''
  }

  // שמירת עדכון שם הכיתה
  saveUpdateClassDialog() {
    if (this.checkedNoAlreadyClass(this.newClass)) {
      this.updatetHttp.updateClass$(this.oldClass, this.newClass).pipe(
        tap(ans => console.log('answer:', ans)),
        tap(ans => this.selectAllClasses())
      ).subscribe()
      this.newClass = ''
      this.oldClass = ''
    }
    else {
      this.ShowExistsUpdateClassDialog = true
    }
    this.showUpdateClassDialog = false;
  }

  // ביטול עדכון שם אחר אם שם הכיתה החדשה כבר קיים במערכת
  hideExistsUpdateClassDialog() {
    this.newClass = ''
    this.oldClass = ''
    this.ShowExistsUpdateClassDialog = false
  }

  // שמירת עדכון שם אחר אם שם הכיתה החדשה כבר קיים במערכת
  updateOtherClassDialog() {
    this.ShowExistsUpdateClassDialog = false
    this.newClass = ''
    this.showUpdateClassDialog = true
  }
  
  //----------------------------------------------------------------------- מחיקת כיתה

  // ביטול מחיקת כיתה
  hideDeleteClassDialog() {
    this.showDeleteClassDialog = false;
    this.newClass = ''
  }

  // שמירת מחיקת כיתה
  saveDeleteClassDialog(oldClass: string) {
    this.showDeleteClassDialog = false;
    this.deleteHttp.deleteStudentsByClass$(oldClass).pipe(
      tap(ans => console.log('answer:', ans))
    ).subscribe()
    this.oldClass = ''
    this.selectAllClasses()
  }

}
