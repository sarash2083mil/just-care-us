import { Component, Input, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NEVER, Observable, observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { InsertService } from 'src/app/services/insert.service';
import { SelectService } from 'src/app/services/select.service';
import { student } from 'src/app/types/student';
import { User } from 'src/app/types/user';
import { Location } from '@angular/common';


@Component({
  selector: 'app-add-class',
  templateUrl: './add-class.component.html',
  styleUrls: ['./add-class.component.scss']
})
export class AddClassComponent implements OnInit {

  classFormGroup: FormGroup = new FormGroup({});
  classFormArrary: FormArray = new FormArray([])
  studentArr: student[] = []
  nameClass: string = ''
  numStudents: number = 0
  add: boolean = false
  noAdd: boolean = false



  constructor(private formBuilder: FormBuilder, private route: ActivatedRoute,
    private insertHttp: InsertService, private router: Router, private selectHttp: SelectService, private _location: Location) {
    this.route.params.subscribe((params: Params) => {
      this.nameClass = params.nameClass;
      this.numStudents = Number(params.numStudents)
      console.log(this.nameClass);
      console.log(this.numStudents);
    });
    this.buildClass()
  }

  buildClass() {
    for (let i = 0; i < this.numStudents; i++) {
      this.classFormArrary.push(
        new FormGroup({
          firstName: new FormControl(''),
          lastName: new FormControl(''),
          idNumber: new FormControl(''),
          gender: new FormControl(''),
          phone1: new FormControl(''),
          phone2: new FormControl(''),
          address: new FormControl(''),
          remarks: new FormControl(''),
          class: new FormControl(this.nameClass),
        })
      )
    }
  }


  ngOnInit(): void {
    console.log('inOninit');
  }

  save() {
    console.log(this.classFormArrary.value);
    if (!this.isClassValid()) {
      alert("יש להכניס ערכים לכל תלמיד בכיתה");
      return;
    }
    this.studentArr = this.classFormArrary.value
    this.insertHttp.addNewClass$(this.studentArr).pipe(
      tap(answer => console.log(answer)),
      tap(answer => answer == 1 ? this.add = true : this.noAdd = true),
      tap(_ => console.log('add', this.add)),
      tap(_ => console.log('noAdd', this.noAdd)),
    ).subscribe()
  }

  isClassValid() {
    const classState = this.classFormArrary.value;
    for (let i = 0; i < classState.length; i++) {
      const student: User = classState[i];
      for (const [key, value] of Object.entries(student)) {
        console.log(`${key}: ${value}`);
        if (key != "remarks" && !value.length) {
          return false;
        }
      }
    }

    return true;
  }


  cancel() {
    if (confirm("האם ברצונך לבטל את הפעולה?")) {
      this.classFormArrary = new FormArray([]);
      this.returnToClassesList();
    }

  }

  returnToClassesList() {
    this._location.back();
  }

  navigateToClassesList() {

  }

  finishAddClassDialog() {
    this.add = false
    this.noAdd = false
    this.router.navigate([this.router.url.search('managerMenu') == 1 ?
      'managerMenu/classes' : 'secretaryMenu/classes'])
  }

}
