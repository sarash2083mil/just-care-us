import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SelectService } from 'src/app/services/select.service';
import { User } from 'src/app/types/user';

@Component({
  selector: 'app-manager-menu',
  templateUrl: './manager-menu.component.html',
  styleUrls: ['./manager-menu.component.scss']
})
export class ManagerMenuComponent implements OnInit {

  selected = '';
  user: User | undefined

  constructor(private router: Router,private selectHttp:SelectService) { }

  ngOnInit(): void {
    this.user = this.selectHttp.getUser()
  }

  menu(path: string){
    this.selected = path;
    this.router.navigate([`managerMenu/${path}`])
  }

}



