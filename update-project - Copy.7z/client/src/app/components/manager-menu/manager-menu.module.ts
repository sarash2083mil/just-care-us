import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';
import { ManagerMenuComponent } from './manager-menu.component';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [
    ManagerMenuComponent,
  ],
  imports: [
    CommonModule,
    AppRoutingModule,
  ],
  exports:[ManagerMenuComponent]
})
export class ManagerMenuModule { }


