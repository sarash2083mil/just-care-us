import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NEVER, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { InsertService } from 'src/app/services/insert.service';
import { SelectService } from 'src/app/services/select.service';
import { User } from 'src/app/types/user';

@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.scss']
})
export class NewUserComponent implements OnInit {

  wasSaved = false;
  noSaveSucceeded: boolean =false
  finishAddUser: Observable<number> = NEVER
  newUser: User = {
    firstName: '',
    lastName: '',
    _id: '',
    idNumber: '',
    phone: '',
    mailAddress: '',
    password: '',
    rule: ''
  }
  allUsers$: Observable<User[]> = NEVER
  formGroup!: FormGroup;
  mouseoverLogin!: boolean;

  constructor(private formBuilder: FormBuilder, private selectHttp: SelectService
    , private insertHttp: InsertService, private router: Router) { }

  ngOnInit() {
    this.noSaveSucceeded = false
    this.formGroup = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      idNumber: ['', Validators.required],
      mailAddress: ['', Validators.required,Validators.email],
      phone: ['', Validators.required,Validators.pattern('[- +()0-9]+')],
      password: ['', Validators.required],
      // nameSchool: ['', Validators.required]
    });
  }

  saveManager() {
    this.wasSaved = true;
    this.newUser = this.formGroup.value
    this.newUser.rule = 'מנהל'
    console.log('new user', this.newUser);
    this.insertHttp.addnewUser$(this.newUser).pipe(
      tap(ans => console.log('insert user?', ans)),
      tap(ans => ans == 1 ?
        this.router.navigate(['']) :
        this.noSaveSucceeded = true
      )
    ).subscribe()
  }

  finishSaveManagerDialog(){
    this.noSaveSucceeded = false
  }

}
