import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NewUserComponent } from './new-user.component';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularDesignModule } from 'src/app/design.module';



@NgModule({
  declarations: [
    NewUserComponent
  ],
  imports: [
    CommonModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AngularDesignModule
  ],
  exports:[NewUserComponent]
})
export class NewUserModule { }
