import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrivateAreaComponent } from './private-area.component';
import { AngularDesignModule } from 'src/app/design.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [PrivateAreaComponent],
  imports: [
    CommonModule,
    AngularDesignModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [PrivateAreaComponent]
})
export class PrivateAreaModule { }
