import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { tap } from 'rxjs/operators';
import { SelectService } from 'src/app/services/select.service';
import { UpdateService } from 'src/app/services/update.service';
import { User } from 'src/app/types/user';

@Component({
  selector: 'app-private-area',
  templateUrl: './private-area.component.html',
  styleUrls: ['./private-area.component.scss']
})
export class PrivateAreaComponent implements OnInit {

  userFormGroup:FormGroup | undefined
  showUpdateUserDialog:boolean=false
  showPassword: any
  user: User = {
    firstName: '',
    lastName: '',
    _id: '',
    idNumber: '',
    phone: '',
    mailAddress: '',
    password: '',
    rule: ''
  }

  constructor(private selectHttp: SelectService, private formBuilder:FormBuilder,private updateHttp:UpdateService) { }

  ngOnInit(): void {
    this.user = this.selectHttp.getUser()
    this.restartFormGroup()
  }
  
  restartFormGroup() {
    this.userFormGroup = this.formBuilder.group({
      firstName: new FormControl(this.user.firstName),
      lastName: new FormControl(this.user.lastName),
      idNumber: new FormControl(this.user.idNumber),
      phone: new FormControl(this.user.phone),
      mailAddress: new FormControl(this.user.mailAddress),
      password: new FormControl(this.user.password),
    })
  }

  // viewPassword() {
  //   this.showPassword = document.querySelector("#password");
  //   this.showPassword.type === "password"?
  //     this.showPassword.type = "text":
  //     this.showPassword.type = "password"
  // }

  // viewPasswordInDialog(){
  //   this.showPassword = document.querySelector("#passwordInDialog");
  //   this.showPassword.type === "password"?
  //     this.showPassword.type = "text":
  //     this.showPassword.type = "password"
  // }

  updateUser(){
    this.showUpdateUserDialog=true
  }

  HideUpdateUserDialog(){
    this.showUpdateUserDialog=false
  }

  saveUpdateUserDialog(){
    this.showUpdateUserDialog=false
    console.log('user in update', this.userFormGroup?.value);
    this.updateHttp.updateUser$(this.user?._id, this.userFormGroup?.value).pipe(
      tap(newUser => console.log('newUser:', newUser)),
      tap(newUser=> this.user=newUser),
      tap(newUser=>this.selectHttp.changeUser(newUser))
    ).subscribe()
  }
}
