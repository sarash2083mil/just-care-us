import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AttendanceMarkingComponent } from './components/attendance-marking/attendance-marking.component';
import { CertificateOfAbsenceComponent } from './components/certificate-of-absence/certificate-of-absence.component';
import { ClassesComponent } from './components/classes/classes.component';
import { EndOfYearComponent } from './components/end-of-year/end-of-year.component';
import { GraphsComponent } from './components/graphs/graphs.component';
import { LoginComponent } from './components/login/login.component';
import { ManagerMenuComponent } from './components/manager-menu/manager-menu.component';
import { SecretaryMenuComponent } from './components/secretary-menu/secretary-menu.component';
import { ViewClassComponent } from './components/view-class/view-class.component';
import { LoggedInGuardService } from './components/login/logged-in-guard.service';
import { AddClassComponent } from './components/add-class/add-class.component';
import { PresentInClassComponent } from './components/present-in-class/present-in-class.component';
import { AbsencesClassComponent } from './components/absences-class/absences-class.component';
import { AbsencesStudentComponent } from './components/absences-student/absences-student.component';
import { PrintAbsencesComponent } from './components/print-absences/print-absences.component';
import { NewUserComponent } from './components/new-user/new-user.component';
import { ViewAllUsersComponent } from './components/view-all-users/view-all-users.component';
import { PrivateAreaComponent } from './components/private-area/private-area.component';
import { TeacherMenuComponent } from './components/teacher-menu/teacher-menu.component';
import { PasswordResetComponent } from './components/password-reset/password-reset.component';
import { AboutComponent } from './components/about/about.component';
import { AppComponent } from './app.component';


const routes: Routes = [
    
    { path: 'home', component: AppComponent, pathMatch: 'full' },
    { path: 'login', component: LoginComponent },
    { path: 'about', component: AboutComponent },
    { path: 'passwordReset/:mail', component: PasswordResetComponent, pathMatch: 'full' },
    { path: 'login/newUser', component: NewUserComponent },
    {
        path: 'managerMenu', component: ManagerMenuComponent, children: [
            { path: 'privateArea', component: PrivateAreaComponent },
            { path: 'endOfYear', component: EndOfYearComponent },
            { path: 'classes', component: ClassesComponent },
            { path: 'attendanceMarking', component: AttendanceMarkingComponent },
            { path: 'graphs', component: GraphsComponent },
            { path: 'certificateOfAbsence', component: CertificateOfAbsenceComponent },
            { path: 'printAbsences/:d1/:d2/:whatToPrint', component: PrintAbsencesComponent },
            { path: 'absencesClass/:nameClass', component: AbsencesClassComponent },
            { path: 'viewClass/:nameClass', component: ViewClassComponent },
            { path: 'absencesStudent/:firstName/:lastName/:_id/:nameClass/:startDate/:endDate', component: AbsencesStudentComponent },
            { path: 'addClass/:nameClass/:numStudents', component: AddClassComponent },
            { path: 'presentInClass/:nameClass', component: PresentInClassComponent },
            { path: 'allUsers', component: ViewAllUsersComponent }
        ]
        , canActivate: [LoggedInGuardService]
    },
    {
        path: 'teacherMenu', component: TeacherMenuComponent, children: [
            { path: 'privateArea', component: PrivateAreaComponent },
            { path: 'attendanceMarking', component: AttendanceMarkingComponent }
        ]
        , canActivate: [LoggedInGuardService]
    },
    { path: 'teacherMenu/presentInClass/:nameClass', component: PresentInClassComponent },
    {
        path: 'secretaryMenu', component: SecretaryMenuComponent, children: [
            { path: 'privateArea', component: PrivateAreaComponent },
            { path: 'classes', component: ClassesComponent },
            { path: 'graphs', component: GraphsComponent },
            { path: 'attendanceMarking', component: AttendanceMarkingComponent },
            { path: 'certificateOfAbsence', component: CertificateOfAbsenceComponent },
            { path: 'printAbsences/:d1/:d2/:whatToPrint', component: PrintAbsencesComponent },
            { path: 'absencesClass/:nameClass', component: AbsencesClassComponent },
            { path: 'viewClass/:nameClass', component: ViewClassComponent },
            { path: 'absencesStudent/:firstName/:lastName/:_id/:nameClass/:startDate/:endDate', component: AbsencesStudentComponent },
            { path: 'addClass/:nameClass/:numStudents', component: AddClassComponent },
            { path: 'presentInClass/:nameClass', component: PresentInClassComponent }
        ]
        , canActivate: [LoggedInGuardService]
    },
   // { path: '', redirectTo: 'home',pathMatch: 'full' }
]

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }



