//ממירי
// import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
 import { MatCheckboxModule } from '@angular/material/checkbox';
// import { MatInputModule } from '@angular/material/input';
// import { MatAutocompleteModule } from '@angular/material/autocomplete';
// import { MatDatepickerModule } from '@angular/material/datepicker';
// import { MatFormFieldModule } from '@angular/material/form-field';
// import { MatRadioModule } from '@angular/material/radio';
// import { MatSelectModule } from '@angular/material/select';
// import { MatSliderModule } from '@angular/material/slider';
// import { MatSlideToggleModule } from '@angular/material/slide-toggle';
// import { MatMenuModule } from '@angular/material/menu';
// import { MatSidenavModule } from '@angular/material/sidenav';
// import { MatBadgeModule } from '@angular/material/badge';
import { MatToolbarModule } from '@angular/material/toolbar';
// import { MatListModule } from '@angular/material/list';
// import { MatGridListModule } from '@angular/material/grid-list';
import { MatCard, MatCardModule } from '@angular/material/card';
// import { MatStepperModule } from '@angular/material/stepper';
// import { MatTabsModule } from '@angular/material/tabs';
// import { MatAccordion, MatExpansionModule, MatExpansionPanel, MatExpansionPanelActionRow, MatExpansionPanelDescription, MatExpansionPanelHeader, MatExpansionPanelTitle } from '@angular/material/expansion';
// import { MatButtonToggleModule } from '@angular/material/button-toggle';
// import { MatChipsModule } from '@angular/material/chips';
// import { MatIconModule } from '@angular/material/icon';
// import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
// import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatDialogClose, MatDialogContent, MatDialogModule } from '@angular/material/dialog';
// import { MatTooltipModule } from '@angular/material/tooltip';
// import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTableModule } from '@angular/material/table';
// import { MatSortModule } from '@angular/material/sort';
// import { MatPaginatorModule } from '@angular/material/paginator';
// import { MatNativeDateModule } from '@angular/material/core';

import { SelectButtonModule } from 'primeng/selectbutton';
import { InputTextModule } from 'primeng/inputtext';
import { InputNumberModule } from 'primeng/inputnumber';
import { ButtonModule } from 'primeng/button';
import { MatButtonModule } from '@angular/material/button';
import { DialogModule } from 'primeng/dialog'
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { ChartModule } from 'primeng/chart';
import { MatSelectModule } from '@angular/material/select';
import { MatNativeDateModule } from '@angular/material/core';
//import {MatOptionModule} from '@angular/material/option';

export const AngularDesignModule =
    [
        //ממירי 
        MatToolbarModule,
        // MatIconModule,
        // MatSidenavModule,
        // MatBadgeModule,
        // MatListModule,
        // MatGridListModule,
        // MatInputModule,
        // MatFormFieldModule,
        // MatSelectModule,
        // MatRadioModule,
        // MatDatepickerModule,
        // MatChipsModule,
        // MatTooltipModule,
         MatTableModule,
        // MatPaginatorModule,
        // MatButtonToggleModule,
        // MatListModule,
        // MatNativeDateModule,
        // MatExpansionModule,
        MatCardModule,
        MatCheckboxModule,
        MatDialogModule,
        SelectButtonModule,
        InputTextModule,
        InputNumberModule,
        ButtonModule,
        DialogModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule,
        ChartModule,
        MatSelectModule,
        MatNativeDateModule
    ]