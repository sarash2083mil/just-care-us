import { DatePipe } from "@angular/common";

export interface student {
    _id?: string
    firstName: string
    lastName: string
    idNumber: String
    gender:string
    phone1: string
    phone2: string
    address: string
    remarks: String
    class: string
    theAbsences?: []
    presentToday?: boolean
}
