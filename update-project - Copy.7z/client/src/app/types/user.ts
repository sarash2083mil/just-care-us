export class User {

   firstName: string;
   lastName: string;
   _id!: string;
   idNumber: string;
   phone: string;
   mailAddress: string;
   password: string;
   rule: string;

   constructor(newUser: { firstName: string; lastName: string; idNumber: string; phone: string; mailAddress: string; password: string; rule: string; }) {
      this.firstName = newUser.firstName;
      this.lastName = newUser.lastName;
      this.idNumber = newUser.idNumber;
      this.phone = newUser.phone;
      this.mailAddress = newUser.mailAddress;
      this.password = newUser.password;
      this.rule = newUser.rule;
   }
}

