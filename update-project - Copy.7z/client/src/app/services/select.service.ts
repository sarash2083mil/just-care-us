import { Injectable } from '@angular/core';
import * as core from '@angular/core';
import { Observable } from 'rxjs';
import { HttpRequestModel } from '../types/http-request.model';
import { User } from '../types/user';
import { HttpServiceBase } from './http-service.base';
import { student } from '../types/student';


@core.Injectable({ providedIn: 'root' })
export class SelectService extends HttpServiceBase {

  user: User = {
    firstName: '',
    lastName: '',
    _id: '',
    idNumber: '',
    phone: '',
    mailAddress: '',
    password: '',
    rule: ''
  }

  private get _serverUrl(): string {
    return `${this.config.ips?.servicePath}select/`;
  }

  //הפונקציה מחזירה אותו דבר כמו הפונקציה השנייה, רק כתובה יותר פשוט
  // checkUsers$(UserName: string,Password:string): Observable<User>  {
  //   return this.post$(new HttpRequestModel({
  //     url: 'http://localhost:52967/api/Users/',
  //     action: 'CheckUsers',
  //     params: { UserName,Password },
  //   }));
  // }

  changeUser(user: User) {
    this.user.firstName = user.firstName
    this.user.lastName = user.lastName
    this.user._id = user._id
    this.user.phone = user.phone
    this.user.idNumber = user.idNumber
    this.user.password = user.password
    this.user.mailAddress = user.mailAddress
    this.user.rule = user.rule
    console.log('changeUser in service', this.user);
    this.getUser();
  }

  setUser(user: { firstName: string; lastName: string; _id: string; phone: string; idNumber: string; password: string; mailAddress: string; rule: string; }) {
    this.user.firstName = user.firstName
    this.user.lastName = user.lastName
    this.user._id = user._id
    this.user.phone = user.phone
    this.user.idNumber = user.idNumber
    this.user.password = user.password
    this.user.mailAddress = user.mailAddress
    this.user.rule = user.rule
  }
  getUser() {
    console.log('getUser in service', this.user);
    return this.user
  }

  getAllUsers$(): Observable<User[]> {
    return this.get$<User[]>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'getAllUsers'
    }));
  }

  checkUsers$(userToCheck: User): Observable<User> {
    return this.post$<User>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'getUserByLogin',
      body: userToCheck
    }));
  }

  getClasses$(): Observable<[]> {
    return this.get$<[]>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'getClasses',
    }));
  }

  getStudentsByClass$(theClass: string): Observable<student[]> {
    return this.get$<student[]>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'getStudentsByClass',
      params: { theClass }
    }));
  }

  getAbsencesInClassesTheMonth$(): Observable<any[]> {
    return this.get$<any[]>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'getAbsencesInClassesTheMonth'
    }));
  }

  getNumStudentsInClasses$(): Observable<any[]> {
    return this.get$<any[]>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'getNumStudentsInClasses'
    }));
  }

  getAbsencesOfAllStudentsInSchool$(startDate: any, endDate: any): Observable<any[]> {
    return this.get$<any[]>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'getAbsencesOfAllStudentsInSchool',
      params: { startDate, endDate }
    }));
  }

  getAbsencesOfStudentsByClass$(nameClass: string, startDate: any, endDate: any): Observable<any[]> {
    return this.get$<any[]>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'getAbsencesOfStudentsByClass',
      params: { nameClass, startDate, endDate }
    }));
  }

  getAbsencesOfStudentById$(_id: string, startDate: any, endDate: any): Observable<student> {
    console.log('innnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn');
    return this.get$<student>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'getAbsencesOfStudentById',
      params: { _id, startDate, endDate }
    }));
  }

  getRuleByMail$(mail: string, password: string): Observable<User> {
    return this.post$<User>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'getRuleByMail',
      params: { mail, password }
    }));
  }
}
