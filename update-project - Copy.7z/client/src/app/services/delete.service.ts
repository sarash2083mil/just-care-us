import { Injectable } from '@angular/core';
import * as core from '@angular/core';
import { Observable } from 'rxjs';
import { HttpRequestModel } from '../types/http-request.model';
import { HttpServiceBase } from './http-service.base';

@core.Injectable({ providedIn: 'root' })
export class DeleteService extends HttpServiceBase {

  private get _serverUrl(): string {
    return `${this.config.ips?.servicePath}delete/`;
  }

  deleteAllSchool$(): Observable<never> {
    return this.get$<never>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'deleteAllSchool'
    }));
  }

  deleteStudentsByClass$(nameClass:string): Observable<number> {
    return this.get$<number>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'deleteStudentsByClass',
      params:{nameClass}
    }));
  }

  deleteOneStudent$(_id:any): Observable<number> {
    return this.get$<number>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'deleteStudentById',
      params:{_id}
    }));
  }
 
  deleteOneUser$(_id:any): Observable<number> {
    return this.get$<number>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'deleteUserById',
      params:{_id}
    }));
  }

}
