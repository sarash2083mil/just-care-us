import { Injectable } from '@angular/core';
import * as core from '@angular/core';
import { Observable } from 'rxjs';
import { HttpRequestModel } from '../types/http-request.model';
import { HttpServiceBase } from './http-service.base';
import { student } from '../types/student';
import { User } from '../types/user';


@core.Injectable({ providedIn: 'root' })
export class UpdateService extends HttpServiceBase {

  private get _serverUrl(): string {
    return `${this.config.ips?.servicePath}update/`;
  }

  updateClass$(oldClass: string, newClass: string): Observable<number> {
    return this.post$<number>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'updateNameClass',
      params: { oldClass, newClass }
    }));
  }

  updateStudent$(_id: string, newStudent: student): Observable<number> {
    return this.post$<number>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'updateStudentById',
      params: { _id },
      body: newStudent
    }));
  }

  updateUser$(_id: any, newUser: student): Observable<User> {
    return this.post$<User>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'updateUserById',
      params: { _id },
      body: newUser
    }));
  }
}
