import { Injectable } from '@angular/core';
import * as core from '@angular/core';
import { Observable } from 'rxjs';
import { HttpRequestModel } from '../types/http-request.model';
import { HttpServiceBase } from './http-service.base';
import { student } from '../types/student';
import { User } from '../types/user';


@core.Injectable({ providedIn: 'root' })
export class InsertService extends HttpServiceBase {

  private get _serverUrl(): string {
        return `${this.config.ips?.servicePath}insert/`;
  }

  addNewClass$(studentArr:student[]): Observable<number> {
    return this.post$<number>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'addStudents',
      body:studentArr
    }));
  }

  addnewStudent$(newStudent:student): Observable<number> {
    return this.post$<number>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'addOneStudent',
      body:newStudent
    }));
  }

  addnewUser$(newUser:User): Observable<number> {
    return this.post$<number>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'addUser',
      body:newUser
    }));
  }

  absencesToday$(studentAbsence:student[]): Observable<number> {
    return this.post$<number>(new HttpRequestModel({
      url: this._serverUrl,
      action: 'addTheAbsences',
      body:studentAbsence
    }));
  }

  
}
























