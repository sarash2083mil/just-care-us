const mongoose = require('mongoose');
const userSchema = require("./userSchema");

//users
//זה השם של ה
//connection
const userModel = mongoose.model(
    "users",
    userSchema
);

module.exports = userModel;




