const mongoose = require('mongoose');

///פה קובעים את המבנה של האובייקטים ב
//DATA BASE
const studentSchema =
    new mongoose.Schema({
        firstName: String,
        lastName: String,
        phone1: String,
        phone2: String,
        address:String,
        idNumber:String,
        gender:String,
        remarks:String,
        class: String,
        theAbsences :Array
    })

   module.exports = studentSchema





