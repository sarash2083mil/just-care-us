class gender {
    MALE = "זכר";
    FEMALE = "נקבה";
}

module.exports =   gender ;
//export default gender;