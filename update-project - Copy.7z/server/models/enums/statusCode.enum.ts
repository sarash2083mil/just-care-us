 enum statusCode {
  ERROR = '500',
  SUCCESS = '200'
}

module.exports = statusCode;