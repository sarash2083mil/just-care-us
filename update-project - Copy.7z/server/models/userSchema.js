const mongoose = require('mongoose');

///פה קובעים את המבנה של האובייקטים ב
//DATA BASE
const userSchema =
    new mongoose.Schema({
        firstName: String,
        lastName: String,
        idNumber: String,
        phone: String,
        mailAddress: String,
        password: String,
        rule: String,
    })

module.exports = userSchema
