const mongoose = require('mongoose');
const studentSchema = require("./studentSchema");

//students
//זה השם של ה
//connection
const studentModel = mongoose.model(
    "students",
    studentSchema
);

module.exports = studentModel;




