
//import * as bodyParser from "body-parser";
//import * as dotenv from "dotenv";
//import * as express from "express";
//import * as mongoose from "mongoose";
//import * as compression from "compression";
const dotenv = require('dotenv');
const express = require('express');
const mongoose = require('mongoose');

dotenv.config();

class App {

    // Express App
    app;
    static mongoConnection;

    constructor() {
        this.app = express();
        //this.appConfig();
        App.dbConfig();
    }

     static  dbConfig() {
        // tslint:disable-next-line:no-debugger
        const mongoUrl = process.env.APP_CONNECTION_STRING;
        console.log(mongoUrl);
        mongoose.connect(`${mongoUrl}`, {
            useUnifiedTopology: true,
            useNewUrlParser: true,
            // useFindAndModify: false,
            autoIndex: true,
            autoCreate: true,
            // poolSize: 10,
            maxPoolSize: 25,
            // useCreateIndex: true
        });
        mongoose.connection.on("error", (err) => { console.log("error connection ", err) });
        mongoose.connection.on("connection", (s) => { console.log("connected successfully !") })
    }

}

//export default new App().app;

module.exports = { myApp: new App().app }
