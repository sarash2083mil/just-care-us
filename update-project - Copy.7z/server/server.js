const myExpress = require('express')
const app = myExpress();
const mongoConnection = require('./app').mongoConnection;

//import {myApp} from './app';

app.use(myExpress.json())

var myCors = require('cors')
//var connectMongoDb = require('./routers/connectMongo');

app.use(myCors());
//app.use(connectMongoDb.connectMongoDb);
const connectDB = require('./routers/dbConnection');
const goToSelect = require('./routers/select')
const goToInsert = require('./routers/insert')
const goToDelete = require('./routers/delete')
const goToUpdate = require('./routers/update')
const sendMessage = require('./routers/sendMessage');
//const connectMongoDb = require('./routers/connectMongo');
//that was just for trial
// sendMessage.sendSMS(msg, '0534468817', function (msg, statusCode) {
//     res.json(msg, statusCode);
// });

app.use('/select', goToSelect)
app.use('/insert', goToInsert)
app.use('/delete', goToDelete)
app.use('/sendMessage', sendMessage.router)

app.listen(3000, () => {
    console.log('http://localhost:3000');
})

