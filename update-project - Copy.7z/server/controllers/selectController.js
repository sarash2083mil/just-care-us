

const getAllStudents = async () => {
    const student = await mongoose.model("students", studentSchema)
    await student.find({}, function (err, student) {
        if (!err) {
            console.log(student);
            res.json(student)
        } else {
            throw err;
        }
    });
}

module.export = { getAllStudents }
