const Router = require('express-promise-router')
const router = new Router();
const nodemailer = require('nodemailer');
const sender = require('./sendSms.helper');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'sof.haderech.message@gmail.com',
    pass: 'vdqwqjscjgbhrmfa'
  }
});

router.get('/resetPassword', async (req, res) => {
  console.log(req.query.mail);
  var message = `<h1>משתמש יקר</h1><p> על מנת לאפס את סיסמתך אנא <a href=http://localhost:4200/passwordReset/${req.query.mail}> לחץ כאן </a></p>`
  var mailOptions = {
    from: 'sof.haderech.message@gmail.com',
    to: req.query.mail,
    subject: 'איפוס סיסמא',
    html: message
  };
  transporter.sendMail(mailOptions, function (error, info) {
    if (error) {
      console.log(error);
      res.json(0)
    } else {
      console.log('Email sent: ' + info.response);
      res.json(1)
    }
  });
})

function sendSMS(msg, phone) {
  sender(msg, phone);
}



module.exports = { router, sendSMS }