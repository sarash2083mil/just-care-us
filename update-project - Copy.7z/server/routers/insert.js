const Router = require('express-promise-router')
const studentModel = require("../models/studentModel");
const userModel = require("../models/userModel");
const mongoose = require('mongoose');
const studentSchema = require("../models/studentSchema");
const userSchema = require("../models/userSchema");
const {sender, asyncSendToMany } = require('./sendSms.helper');
// import { statusCode } from '../models/enums/gender.enum';
//const { gender } = require('../models/enums/gender.enum');
//const { statusCode } = require('../models/enums/statusCode.enum');
const router = new Router();

//הוספת תלמיד
router.post('/addOneStudent', async (req, res) => {
    console.log("req.body", req.body);
   // await mongoose.connect('mongodb://localhost:27017/School');
    const student = new studentModel(req.body)
    await student.save()
    res.json(1)
})

//הוספת כמה תלמידים
router.post('/addStudents', async (req, res) => {
    console.log("req.body", req.body);
  //  await mongoose.connect('mongodb://localhost:27017/School');
    req.body.forEach(element => {
        (new studentModel(element)).save()
    });
    res.json(1)
})

//הוספת משתמש
router.post('/addUser', async (req, res) => {
    console.log("req.body", req.body);
   // await mongoose.connect('mongodb://localhost:27017/School');
    const user = await mongoose.model("users", userSchema)
    await user.find({ idNumber: req.body.idNumber, password: req.body.password }, function (err, user) {
        console.log("user", user);
        if (user.length == 0) {
            const user = new userModel(req.body)
            user.save();
            console.log('user', user);
            res.json(1);
            return;
        }
        res.json('exists');
    }).clone().catch(function (err) { console.log(err) })
})

//הוספת חיסורים לתלמידים חסרים
//נשלח מערך עם ה
//id
//של כל התלמידים החסרים
//ומתווסף לכל תלמיד חסר למערך החיסורים שלו התאריך של היום
//addToSet לא מכניס ערך כפול למערך
//בגלל שהתאריך כולל גם שניות יכול להיות שאם ילחצו כמה פעמים 
//התאריך של היום יוכנס כמה פעמים עם הבדלים בזמן השניות
router.post('/addTheAbsences', async (req, res) => {
    console.log(new Date());
    console.log("absence",req);
    const sendingResponse = await asyncSendToMany(req.body);
   // await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    student.updateMany({ _id: { $in: req.body } }, {
        $addToSet: {
            theAbsences:
            {
                theFullDate: new Date(),
                theDate: new Date().toLocaleDateString(),
                theTime: new Date().toLocaleTimeString(),
                numDayInWeek: new Date().getUTCDay(),
                dateToGraphs: new Date().getUTCMonth() + ' ' + new Date().getUTCFullYear()
            }
        }
    }, function (err, student) {
        if (!err) {
          //  getAllStudents();
            res.json(1);
        } else {
            throw err;
        }
    }).clone().catch(function (err) { console.log(err) })
})

module.exports = router

