const Router = require('express-promise-router')
const mongoose = require('mongoose');
//const db = require('./connectMongo');
const router = new Router();
const studentSchema = require('../models/studentSchema');
const userSchema = require("../models/userSchema");
const db = require('../app').mongoConnection;


//שליפת כל המשתמשים
router.get('/getAllUsers', async (req, res) => {
   // await mongoose.connect('mongodb://localhost:27017/School');
    const user = await mongoose.model("users", userSchema)
    await user.find({}, function (err, user) {
        console.log("user", user);
        res.json(user);
    }).clone().catch(function (err) { console.log(err) })
})

//שליפת תפקיד משתמש לפי מספר זהות וסיסמא
router.post('/getRuleByUser', async (req, res) => {
    console.log("req.body", req.body);
    //await mongoose.connect('mongodb://localhost:27017/School');
    const user = mongoose.model("users", userSchema)
    await user.find({ idNumber: req.body.idNumber, password: req.body.password }, { rule: 1 }, function (err, user) {
        console.log("user", user);

        res.json(user && user[0] ? user[0].rule : user);
        //   res.json(user );

    }).clone().catch(function (err) { console.log(err) })
})

//שליפת תפקיד משתמש לפי כתובת המייל
router.post('/getRuleByMail', async (req, res) => {
    console.log("req.query.mail", req.query.mail);
    console.log("req.query.password", req.query.password);
    //await mongoose.connect('mongodb://localhost:27017/School');
    const user = await mongoose.model("users", userSchema)
    await user.findOneAndUpdate({ mailAddress: req.query.mail }, { password: req.query.password }, { rule: 1 }, function (err, user) {
        console.log("user", user);
        res.json(user);
    }).clone().catch(function (err) { console.log(err) })
})

//שליפת משתמש לפי מספר זהות וסיסמא
router.post('/getUserByLogin', async (req, res) => {
    // await mongoose.connect('mongodb://localhost:27017/School');
   // console.log(db?.model);
    const user = await mongoose.model("users", userSchema)
    // const resi = await db.getDocumentsByQuery('users');
    //  console.log("user", resi);
    // const user = await db.users.find({ idNumber: req.body.idNumber, password: req.body.password });
    // console.log("user", user);
    await user.find({ idNumber: req.body.idNumber, password: req.body.password }, function (err, user) {
        console.log("user print", user);
        //user = [{ firstName: 'Sara', lastName: 'moriel', rule: 'מזכירה', mailAddress: 'sarash2083@gmail.com' }];
        // res.json(user && user[0] ? user[0].rule : user);
        // res.json(user );
        res.json(user && user[0] ? user[0] : user);
    }).clone().catch(function (err) { console.log(err) })
})

//שליפת כל התלמידים
router.get('/getAllStudents', async (req, res) => {
    //await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    await student.find({}, function (err, student) {
        if (!err) {
            console.log(student);
            res.json(student)
        } else {
            throw err;
        }
    }).clone().catch(function (err) { console.log(err) })
})

//שליפת תלמיד אחד לפי id
router.get('/getOneStudentById', async (req, res) => {
    console.log(req.query._id);
    //await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    student.findById({ _id: req.query._id }, function (err, student) {
        if (!err) {
            console.log(student)
            res.json(student)
        } else {
            throw err;
        }
    }).clone().catch(function (err) { console.log(err) })
})

//שליפת כמה תלמידים לפי
//id
//נשלח מערך עם ה
//id
//שלהם
//וחוזרים כל הפרטים של התלמידים
router.post('/getStudentsById', async (req, res) => {
    console.log(req.body);
    //await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    student.find({ _id: { $in: req.body } }, function (err, student) {
        if (!err) {
            console.log(student);
            res.json(student)
        } else {
            throw err;
        }
    }).clone().catch(function (err) { console.log(err) })
})

//שליפת תלמידים לפי כיתה
//הפונ' מקבלת את שם הכיתה ומחזירה את כל התלמידים שבכיתה זו
router.get('/getStudentsByClass', async (req, res) => {
    console.log("req.query.theClass", req.query.theClass);
    //await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    await student.find({ class: req.query.theClass }, function (err, student) {
        if (!err) {
            console.log(student);
            res.json(student)
        } else {
            throw err;
        }
    }).sort({ "lastName": 1, "firstName": 1 }).clone().catch(function (err) { console.log(err) })
})

//שליפת כמות החיסורים החודש לפי כיתות
router.get('/getAbsencesInClassesTheMonth', async (req, res) => {
    //await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    await student.aggregate([
        { "$unwind": { path: "$theAbsences" } },
        { "$match": { "theAbsences.dateToGraphs": new Date().getUTCMonth() + ' ' + new Date().getUTCFullYear() } }
        , {
            "$group": {
                "_id": "$class",
                numAbsences: {
                    "$sum": 1
                }
            }
        }, { "$sort": { "_id": 1 } }],
        function (err, student) {
            if (!err) {
                console.log('req:', student);
                res.json(student)
            } else {
                throw err;
            }
        })
})

//שליפת כל הכיתות
router.get('/getClasses', async (req, res) => {
    //await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    await student.aggregate([{ "$group": { "_id": "$class" } }, { "$sort": { "_id": 1 } }], function (err, student) {
        if (!err) {
            console.log('req:', student);
            var arrClasses = []
            student.forEach(classes => {
                for (const key in classes) {
                    if (Object.hasOwnProperty.call(classes, key)) {
                        arrClasses.push(classes[key]);
                    }
                }
            });
            console.log('arrClasses:', arrClasses);
            res.json(arrClasses)
        } else {
            throw err;
        }
    })
})

//שליפת כמות התלמידים בכל כיתה
router.get('/getNumStudentsInClasses', async (req, res) => {
    //await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    await student.aggregate([{
        "$group": {
            "_id": "$class", numStudents: {
                $sum: 1
            }
        }
    }, { "$sort": { "_id": 1 } }], function (err, student) {
        if (!err) {
            res.json(student)
        } else {
            throw err;
        }
    })
})

//שליפת כל חיסורי התלמיד שבטווח הרצוי
//ממויינים בסדר עולה
//משום מה לא עובד
router.get('/getAbsencesOfStudentById', async (req, res) => {
    console.log('in serverrrrrrrrrrrrrrrrrrrrrrrr');
    console.log('id', req.query._id);
    console.log('startDate', req.query.startDate);
    console.log('endDate', req.query.endDate);
    //await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    const idAsObject = mongoose.Types.ObjectId(req.query._id);
    //check why id isn't relevant
    await student.aggregate([
        {
            "$match": {
               // _id: req.query._id
                _id:idAsObject
            }
        },
        {
            "$unwind": {
                path: "$theAbsences"
            }
        },
        {
            "$match": {
                "theAbsences.theFullDate": {
                    $gte: new Date(req.query.startDate),
                    $lte: new Date(req.query.endDate)
                }
            }
        },
        {
            "$sort": {
                "theAbsences.theDate": 1
            }
        }
        , {
            "$project": {
                firstName: 1,
                lastName: 1,
                theAbsences: 1,
                class: 1
            }
        },
        {
            "$group": {
                _id: "$_id",
                theAbsences: {
                    $push: "$theAbsences"
                },
                firstName: {
                    $addToSet: "$firstName"
                },
                lastName: {
                    $addToSet: "$lastName"
                },
                class: {
                    $addToSet: '$class' 
                }
            }
        },
        {
            "$unwind": {
                path: "$firstName"
            }
        },
        {
            "$unwind": {
                path: "$lastName"
            }
        }
    ],
        function (err, student) {
            if (!err) {
                console.log('res:', student);
                res.json(student[0])
            } else {
                throw err;
            }
        })
})

//שליפת כל חיסורי תלמידי הכיתה שבטווח הרצוי
//ממויינים בסדר עולה לפי שם המשפחה
router.get('/getAbsencesOfStudentsByClass', async (req, res) => {
    console.log('class', req.query.nameClass);
    console.log('startDate', req.query.startDate);
    console.log('endDate', req.query.endDate);
    //await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    await student.aggregate([
        {
            "$match": {
                "class": req.query.nameClass
            }
        },
        {
            "$unwind": {
                path: "$theAbsences"
            }
        },
        {
            "$match": {
                "theAbsences.theFullDate": {
                    $gte: new Date(req.query.startDate),
                    $lte: new Date(req.query.endDate)
                }
            }
        }
        , {
            "$sort": {
                "theAbsences.theDate": 1
            }
        }
        , {
            "$project": {
                firstName: 1,
                lastName: 1,
                class: 1,
                theAbsences: 1
            }
        },
        {
            "$group": {
                _id: "$_id",
                theAbsences: {
                    $push: "$theAbsences"
                },
                firstName: {
                    $addToSet: "$firstName"
                },
                lastName: {
                    $addToSet: "$lastName"
                },
                class: {
                    $addToSet: "$class"
                }
            }
        },
        {
            "$unwind": {
                path: "$firstName"
            }
        },
        {
            "$unwind": {
                path: "$lastName"
            }
        },
        {
            "$unwind": {
                path: "$class"
            }
        },
        {
            "$sort": {
                "lastName": 1
            }
        }
    ],
        function (err, student) {
            if (!err) {
                console.log('res:', student);
                res.json(student)
            } else {
                throw err;
            }
        })
})

//שליפת כל חיסורי תלמידי בית הספר שבטווח הרצוי
//ממויינים דבר ראשון לפי כיתה ואח"כ לפי שם משפחה
//ולכל תלמיד מערך החיסורים ממויינים ג"כ בסדר עולה
router.get('/getAbsencesOfAllStudentsInSchool', async (req, res) => {
    console.log('startDate', req.query.startDate);
    console.log('endDate', req.query.endDate);
    //await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    await student.aggregate([
        {
            "$unwind": {
                path: "$theAbsences"
            }
        },
        {
            "$match": {
                "theAbsences.theFullDate": {
                    $gte: new Date(req.query.startDate),
                    $lte: new Date(req.query.endDate)
                }
            }
        }
        , {
            "$sort": {
                "theAbsences.theDate": 1
            }
        }
        , {
            "$project": {
                firstName: 1,
                lastName: 1,
                theAbsences: 1,
                class: 1
            }
        },
        {
            "$group": {
                _id: "$_id",
                theAbsences: {
                    $push: "$theAbsences"
                },
                firstName: {
                    $addToSet: "$firstName"
                },
                lastName: {
                    $addToSet: "$lastName"
                },
                class: {
                    $addToSet: "$class"
                }
            }
        },
        {
            "$unwind": {
                path: "$firstName"
            }
        },
        {
            "$unwind": {
                path: "$lastName"
            }
        },
        {
            "$unwind": {
                path: "$class"
            }
        },
        {
            "$sort": {
                "class": 1,
                "lastName": 1
            }
        }
    ],
        function (err, student) {
            if (!err) {
                console.log('res:', student);
                res.json(student)
            } else {
                throw err;
            }
        })
})

module.exports = router






