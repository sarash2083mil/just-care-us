
const mongoose = require('mongoose');

let db ;
//= connectMongoDb();
async function connectMongoDb() {
    if (!db) {
        db = await mongoose.connect('mongodb://localhost:27017/School');
        console.log('db is connected');
        return db;
    }

}

module.exports = { connectMongoDb, db };
