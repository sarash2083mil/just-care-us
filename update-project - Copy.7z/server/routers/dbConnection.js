

const { collection } = require('../models/studentModel');


// module.exports = conn;
var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb://localhost:27017/';
var databaseName = 'School';
var dbo;

//connect();


function connect() {
    MongoClient.connect(url, function (err, db) {
        try {
            if (err) throw err;
            dbo = db.db(databaseName);
            console.log('db connected successfully');
            console.log(db);
            // dbo.collection("students").find({}).toArray(function(err, result) {
            //     if (err) throw err;
            //     console.log(result);
            //   //  db.close();
            //   });
        }
        catch (err) {
            console.log(err);
        }

        //   var query = { address: "Park Lane 38" };
    });
}

//connect();

async function getDocumentsByQuery(collection, query) {
    if (!dbo)
        connect();
    var res = dbo.collection(collection).find(query);
    if (res)
        res = res.toArray();
    return res;
//    .toArray(function (err, result) {
//         if (err) throw err;
//         console.log('result', result);
//         // db.close();
//     });
}

module.exports = { getDocumentsByQuery: getDocumentsByQuery };