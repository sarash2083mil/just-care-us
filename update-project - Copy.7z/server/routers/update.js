const Router = require('express-promise-router')
const mongoose = require('mongoose');
const router = new Router();
const studentModel = require("../models/studentModel");
const studentSchema = require('../models/studentSchema');
const userSchema = require("../models/userSchema");

//עדכון תלמיד לפי
//id
router.post('/updateStudentById', async (req, res) => {
    console.log(req.query._id);
    console.log(req.body);
    await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    await student.findOneAndUpdate({ _id: req.query._id },{$set: req.body},{new:true}, function (err, student) {
        if (!err) {
            console.log(student);
            res.json(1)
        } else {
            throw err;
        }
    }).clone().catch(function (err) { console.log(err) })
})

//עדכון משתמש לפי
//id
router.post('/updateUserById', async (req, res) => {
    console.log(req.query._id);
    console.log(req.body);
    await mongoose.connect('mongodb://localhost:27017/School');
    const user = await mongoose.model("users", userSchema)
    await user.findOneAndUpdate({ _id: req.query._id },{$set: req.body},{new:true}, function (err, user) {
        if (!err) {
            console.log(user);
            res.json(user)
        } else {
            throw err;
        }
    }).clone().catch(function (err) { console.log(err) })
})

//עדכון כיתה 
router.post('/updateNameClass', async (req, res) => {
    console.log(req.query.oldClass);
    console.log(req.query.newClass);
    await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    await student.updateMany({ class: req.query.oldClass },{$set: {class: req.query.newClass}},{new:true}, function (err, student) {
        if (!err) {
            console.log(student);
            res.json(1)
        } else {
            throw err;
        }
    }).clone().catch(function (err) { console.log(err) })
})

module.exports = router