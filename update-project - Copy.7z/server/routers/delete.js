const Router = require('express-promise-router')
const mongoose = require('mongoose');
const router = new Router();
const studentSchema = require('../models/studentSchema');
const userSchema = require("../models/userSchema");

//מחיקת כל המשתמשים
router.get('/deleteAllUsers', async (req, res) => {
    await mongoose.connect('mongodb://localhost:27017/School');
    const user = await mongoose.model("users", userSchema)
    await user.deleteMany({}, function (err, user) {
        if (!err) {
            console.log(user);
            res.json(user)
        } else {
            throw err;
        }
    }).clone().catch(function (err) { console.log(err) })
})

//מחיקת משתמש לפי id
router.get('/deleteUserById', async (req, res) => {
    console.log(req.query._id);
    await mongoose.connect('mongodb://localhost:27017/School');
    const user = await mongoose.model("users", userSchema)
    await user.findByIdAndDelete({ _id: req.query._id }, function (err, user) {
        if (!err) {
            console.log(user);
            res.json(1)
        } else {
            throw err;
        }
    }).clone().catch(function (err) { console.log(err) })
})

//מחיקת תלמיד לפי id
router.get('/deleteStudentById', async (req, res) => {
    console.log(req.query._id);
    await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    await student.findByIdAndDelete({ _id: req.query._id }, function (err, student) {
        if (!err) {
            console.log(student);
            res.json(1)
        } else {
            throw err;
        }
    }).clone().catch(function (err) { console.log(err) })
})
//מחיקת כל התלמידים בבי"הס
router.get('/deleteAllStudentsInSchool', async (req, res) => {
    await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    await student.deleteMany({}, function (err, student) {
        if (!err) {
            console.log(student);
            res.json(student)
        } else {
            throw err;
        }
    }).clone().catch(function (err) { console.log(err) })
})

//מחיקת תלמידים לפי כיתות
router.get('/deleteStudentsByClass', async (req, res) => {
    console.log(req.query.nameClass);
    await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    await student.deleteMany({ class: req.query.nameClass }, function (err, student) {
        if (!err) {
            console.log(student);
            res.json(1)
        } else {
            throw err;
        }
    }).clone().catch(function (err) { console.log(err) })
})
//סוף שנה-מחיקת כל התלמידים
router.get('/deleteAllSchool', async (req, res) => {
    await mongoose.connect('mongodb://localhost:27017/School');
    const student = await mongoose.model("students", studentSchema)
    await student.deleteMany({}, function (err, student) {
        if (!err) {
            console.log(student);
            res.json(true)
        } else {
            throw err;
        }
    }).clone().catch(function (err) { console.log(err) })
})

module.exports = router
