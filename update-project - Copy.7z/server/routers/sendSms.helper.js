const { STATUS_CODES } = require('http');

const accountSid = 'ACa005ac50beca0ceff56ce52b0568517e';
//process.env.TWILIO_ACCOUNT_SID;
const authToken = '28cad436d73ee9ab98b341f450ab9901';
//process.env.TWILIO_AUTH_TOKEN;
const client = require('twilio')(accountSid, authToken);
const toNumber = '+9720534468817'
//this will act as your last resort for gaining access to this account.
const lastResourceForAccont = 'Bb_bD7saAzcSmHWsUC7BaY4x5gUM6_ffVktO6wcX';
//const gender = require('../models/enums/gender.enum');
//import gender from '../models/enums/gender.enum';
//const statusCode = require('../models/enums/statusCode.enum');
class gender {
    MALE = "זכר";
    FEMALE = "נקבה";
}


const asyncSendToMany = async (studentsList) => {
    console.log('here',studentsList);
    if (studentsList.length) {
        for (let i = 0; i < studentsList.length; i++) {
            const student = studentsList[i];
            if (student && (student.phone1 || student.phone2)) {
                let phone;
                phone = student.phone1.length ? student.phone1 : student.phone2;
                const isMale = student.gender == 'זכר';
                const msg = ` הורה יקר,שלום רב,רצינו לעדכן מתוך דאגה לשלום ילדך כי ${isMale ? "בנך" : "בתך"} ` + `לא הופיע היום ללמודים `;
                const res = await send(msg, phone);
                // sender(msg, phone, function (msg, status) {
                //     if (status == statusCode.ERROR) throw msg;
                //     else {
                //         console.log(msg);
                //     }
                // });
            }

        }
    }
}


//the better is to get the country prefix by cooardinates ...
function send(msg, toNumber, callback) {
    console.log('toNumber',toNumber)
    fromNumber = '850 783-1214';
    prefix = '+972';
    return client.messages
        .create({
            body: msg,
            from: fromNumber,
            to: prefix + toNumber
        })
        .then(message => {
            console.log(message.sid);
            if (typeof callback == Function)
                callback(message, 200);
        })
        .catch(err => {
            console.log(err)
            if (typeof callback == Function)
                callback(err, 500);
        }).finally(() => {
            console.log('in finally!')
        })
}


module.exports = { send, asyncSendToMany };



